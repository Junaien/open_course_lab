import java.util.Scanner;
import java.util.NoSuchElementException;
import java.io.PrintWriter;
class BankAccount {
    
    //Fields
    private String firstName;
    private String lastName;
    private String address;
    private String userName;
    private String hashOfPIN;
    private int balance;
    
    /*
    public static void main(String[] args){
        Scanner terminal = new Scanner(System.in);
        String a = terminal.next();
        System.out.println(isValidName(a));
        
        int b = terminal.nextInt();
        System.out.println(isValidPIN(b));
    }*/
    

    //constructor
    public BankAccount(String firstName,String lastName,String userName,String hashOfPIN){
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.hashOfPIN = hashOfPIN;
        address = " ";
        balance = 0;
    }
    
    public BankAccount(Scanner in){
        
        
        String line;
        line = in.nextLine();
        line.trim();
        String[] informations = line.split("\\|");
        firstName = informations[0];
        lastName = informations[1];
        address = informations[2];
        userName = informations[3];
        hashOfPIN = informations[4];
        balance = Integer.parseInt(informations[5]);
        
       
    }
    
    public static String hashOf(String pin){
        if(pin == null || pin.length() != 4){
            return null;
        }
        String hash = "";
        for(int i=0; i<4;++i){
            int digit = (int)pin.charAt(i);
            hash +="" + (digit | digit % 3);
            hash +="" + (((digit+i)%5) *digit)+i;
            hash +="" + digit%2;
        }
        
        
        return hash;
    }
    
    public BankAccount(String firstName,String lastName,String userName,String hashOfPIN,
                          String address,int balance){
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.hashOfPIN = hashOfPIN;
        this.address = address;
        this.balance = balance;
    }
    
    //copy constructor
    public BankAccount(BankAccount other){
        this.firstName = other.firstName;
        this.lastName = other.lastName;
        this.userName = other.userName;
        this.hashOfPIN = other.hashOfPIN;
        this.address = other.address;
        this.balance = other.balance;
    }
    
    
    
    //public
    //static method
    
    
    //behavior:check if the name passed in only contains letter
    //argument: String to be checked
    //return: true if string only contains characters,false otherwise
    public static boolean isValidName(String name){
       
        char[] chars =  name.toCharArray();
        
        for(char c: chars){
            if(!Character.isLetter(c) && c != '-' && c !=' ')
                return false;
            
        }
        
        return true;
    }
    
    //behavior:  check if the name passed in only contains letter and numbers 
    //argument:  String to be checked
    //return:    true if string only contains characters,false otherwise
    public static boolean isValidUserName(String userName){
        
        char[] chars =  userName.toCharArray();
        for(char c: chars){
            if(!Character.isLetter(c) && !Character.isDigit(c))
                return false;
        }
        return true;
    }
    
    
    
    //behavior:  check if PIN number contains only 4 digits
    //argument: integer hashOfPIN to be check
    //return: true if integer contains only 4 digits
    public static boolean isValidPIN(String pin){
        if(pin.length()!=4){
            return false;
        }
        for(int i=0; i<pin.length();i++){
            char c = pin.charAt(i);
            if(!Character.isDigit(c))
                return false;
        }
        return true;
    }
    
    
    
    /*behavior:  this function gurranttes to return a valid name 
                 prompt user to enter a valid name until they do
                 if user enter invalid input, print the useage rule*/    
    //argument:  what to enter
    //return:    a valid name
    public static String getValidNameFromUser(Scanner in,String whatToEnter){
        System.out.println("Enter your "+ whatToEnter+":");
        String validName ="letters";
        boolean exit = false;
        while(!exit){
            
            
            try{
                validName = in.next();
                if(!isValidName(validName)){
                    System.out.println("Invalid "+ whatToEnter+"!");
                    System.out.println("\nUsage: only letters are accepted!");
                    continue;
                }
                exit = true;
            }catch(Exception ex){
                System.out.println("Invalid Input!");
                System.out.println("\nUsage: only letters are accepted!");
                continue;
            }finally{
                BankMenu.clearBuffer(in);        
            }
        
        }
        return validName;
        
        
    }
    
    
    
    /*behavior:  prompt user to enter a valid username until they do
                 if user enter invalid input, print the useage rule*/ 
    //return:  a valid username
    public static String getValidUserNameFromUser(Scanner in,String whatToEnter){
        System.out.println("Enter your "+ whatToEnter+":");
        String validUserName ="lettersORnumbers";
        boolean exit = false;
        while(!exit){
        
            try{
                validUserName = in.next();
                if(!isValidUserName(validUserName)){
                    System.out.println("Invalid "+ whatToEnter+"!");
                    System.out.println("\nUsage: only letters and numbers are accepted!");
                    continue;
                }
                exit = true;
            }catch(Exception ex){
                System.out.println("Invalid "+ whatToEnter+"!");
                System.out.println("\nUsage: only letters and numbers are accepted!");
                continue;
            }finally{
                BankMenu.clearBuffer(in);        
            }
        
        }
        return validUserName;
    }
    
    
    
    /*behavior:  prompt user to enter a valid PIN until they do
                 if user enter invalid input, print the useage rule*/ 
    //return:  a valid PIN
    public static String getValidPINFromUser(Scanner in,String whatToEnter){
        System.out.println("Enter your "+ whatToEnter+":");
        String validPIN = null;
        boolean exit = false;
        while(!exit){
        
            try{
                validPIN = in.next();
                if(!isValidPIN(validPIN)){
                    System.out.println("Invalid "+ whatToEnter+"!");
                    System.out.println("\nUsage: only 4-digit number are accepted!");
                    continue;
                }
                exit = true;
            }catch(Exception ex){
                System.out.println("Invalid "+ whatToEnter+"!");
                System.out.println("\nUsage: only 4-digit number are accepted!");
                continue;
            }finally{
                BankMenu.clearBuffer(in);        
            }
        
        }
        return validPIN;
    }
    
    
    //public
    //instance method
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public String getAddress(){
        return address;
    }
    public int getBalance(){
        return balance;
    }
    public String getUserName(){
        return userName;
    }
    public String getHashOfPIN(){
        return hashOfPIN;
    }
    
    
    
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    public void setlastName(String lastName){
        this.lastName = lastName;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public void setBalance(int balance){
        this.balance = balance;
    }
    public void setUserName(String userName){
        this.userName = userName;
    }
    public void setPIN(String hashOfPIN){
        this.hashOfPIN= hashOfPIN;
    }
    
    
    public void addBalance(int amount) throws NumberIsNegative{
        if(amount<0)
            throw new NumberIsNegative("Number can't be negative!");
        balance = balance + amount;
    }
    
    public void subtractBalance (int amount)throws NumberIsNegative   
                                            ,NumberIsOverLimit{
        if(amount<0)
            throw new NumberIsNegative("Number can't be negative!");
        if(amount>balance)
            throw new NumberIsOverLimit("Amount number is over deposit limit!");
        
        balance = balance - amount;
    }
    
    public void writeToFile(PrintWriter pw){
        
        
        pw.print(firstName+"|");
        pw.print(lastName+"|");
        pw.print(address+"|");
        pw.print(userName+"|");
        pw.print(hashOfPIN+"|");
        pw.print(balance+"\n");
        pw.flush();
    }
    
}

