import java.util.Scanner;
public class Main{
     public static void main(String[] args){
        /*String b ="a|b|c|d|e";
        String[] a = b.split("\\|");
         for(String i:a){
             System.out.print(i);
         }*/
        BankMenu.terminal = new Scanner(System.in);
        Bank bank1 = new Bank("AMERICAN BANK");
        BankMenu.landingMenu(bank1);
            
        BankMenu.terminal.close();
        
    }
}