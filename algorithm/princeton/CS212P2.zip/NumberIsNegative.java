public class NumberIsNegative extends Exception{
    public NumberIsNegative(String message){
       super(message);
    }
}