// implementing SortedSLLClass
public class SortedSLLClass {
 // fill in different fields
    private Node head = null;
    private int size = 0;

    //Node class
    private class Node{
        private int val;
        private Node next;
        public Node(int val, Node next){
            this.val = val;
            this.next = next;
        }
    }

    // constructor
    public SortedSLLClass(){
        // fill in
    }

    // copy constructor: copy the content of otherSSLL into this one
    // you need this constructor
    public SortedSLLClass(SortedSLLClass otherSSLL){
        // fill in
        //defensive copying from otherSSLL
        if (otherSSLL == null){
            return;
        }

        size = otherSSLL.size;
        Node dummyNode = new Node(-1, null);
        Node curOther = otherSSLL.head;
        Node curThis = dummyNode;
        while(curOther != null){
            curThis.next = new Node(curOther.val,null);
            curOther = curOther.next;
            curThis = curThis.next;
        }
        head = dummyNode.next;
    }

    //helper function for insert
    private Node insert(Node x, int val){
        if(x == null){
            size ++;
            return new Node(val,null);
        }
        //recursively insert new node
        if(val < x.val){
            Node newNode = new Node(val,x);
            size ++;
            return newNode;
        }else if(val > x.val){
          x.next = insert(x.next, val);
        }
        //if val == x.val  do nothing
        return x;

    }
    // insert an integer value into the list
    public boolean insert(int val){
        // fill in
        int previousSize = size;
        head = insert(head, val);
        //check size to see whether insert successfully
        if(previousSize == size)return false;
        else return true;

    }

    // merge otherSSLL into the current list (naive)
    // read and insert elements from otherSSLL one-by-one into this list
    public void merge_naive(SortedSLLClass otherSSLL){
        // fill in
        if(otherSSLL == null)return;
        Node cur = otherSSLL.head;
        while(cur != null){
            insert(cur.val);
            cur = cur.next;
        }
    }

    // merge other SSLL into the current list (smart)
    // use two synchronized pointers to merge
    // it is easier if you start a new list of nodes
    // after merging, you can use this list of nodes
    // to replace the content of the current one
    public void merge_smart(SortedSLLClass otherSSLL){
        // fill in

        Node dummyNode = new Node(-1, head);
        Node thisNode = dummyNode;
        Node otherNode = otherSSLL.head;

        while(otherNode != null){
            //run out of thisSSLL
            if(thisNode.next == null){
                thisNode.next = new Node(otherNode.val, null);
                size++;
                otherNode = otherNode.next;
                thisNode = thisNode.next;
                continue;
            }

            if(thisNode.next.val < otherNode.val){
                thisNode = thisNode.next;
            }else if(thisNode.next.val ==  otherNode.val){
                otherNode = otherNode.next;
            }else{
                Node newNode = new Node(otherNode.val,thisNode.next);
                thisNode.next = newNode;
                size++;
                thisNode= thisNode.next;
                otherNode = otherNode.next;
            }
        }
        dummyNode = dummyNode.next;
        head  = dummyNode;
    }

    // get all elements of the list, store them in an array
    public int[] getAllElements(){
        // dummy code, replace it for your own program

        int[] result = new int[size];
        Node cur = head;
        int i = 0;
        while(cur != null){
            result[i] = cur.val;
            cur = cur.next;
            i++;
        }
        return result;
    }
    //helper function
    private void print(){

        Node cur = head;
        while(cur != null){
          System.out.print(cur.val + "-> " );
          cur = cur.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args)
    {
        //Testing copy constructor
        SortedSLLClass s1 = new SortedSLLClass(null);
        s1.insert(2);
        s1.insert(3);
        SortedSLLClass s2 = new SortedSLLClass(s1);
        System.out.print("S2: ");
        s2.print();

        //Testing insert
        System.out.print("S1: ");
        s1.print();
        System.out.println("s1 insert 3......");
        s1.insert(3);
        System.out.print("S1: ");
        s1.print();
        System.out.println("s1 insert 1...... and 4 and 10");
        s1.insert(1);
        s1.insert(4);
        System.out.print("S1: ");
        s1.print();

        //Testing merge
        SortedSLLClass s3 = new SortedSLLClass(null);
        int[] a = s3.getAllElements();
        System.out.println("s3 call getAllElements, size = " + a.length);
        System.out.println("Merge s3 with s2....");
        s3.merge_smart(s2);
        s3.print();
        System.out.println("Merge s3 with s1....");
        s3.merge_naive(s1);
        s3.print();

        s1 = new SortedSLLClass();
        s2 = new SortedSLLClass();
        System.out.println("Merge empty with empty list....");
        s1.merge_smart(s2);
        s1.print();
    }
}
