Problem finished:  1 , 2 , 3

Platform I am operating on: Mac OX
