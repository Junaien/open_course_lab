public class CircularSuffixArray {
   // circular suffix array of s
   private static final int CUTOFF = 15;
   private String input;
   private int[] index;
   private int n;
   public CircularSuffixArray(String s){
       if (s == null)throw new IllegalArgumentException();
       input = s;
       n = s.length();
       index = new int[n];
       for(int i = 0; i < n; i++){
           index[i] = i;
       }
       sort(input, 0, n-1, 0);
   }

    private void sort(String a, int lo, int hi, int d) {

        // cutoff to insertion sort for small subarrays
        if (hi <= lo + CUTOFF) {
            insertion(a, lo, hi, d);
            return;
        }

        int lt = lo, gt = hi;
        int v = charAt(a, index[lo], d);
        int i = lo + 1;
        while (i <= gt) {
            int t = charAt(a, index[i], d);
            if      (t < v) exch(lt++, i++);
            else if (t > v) exch(i, gt--);
            else               i++;
        }

        // a[lo..lt-1] < v = a[lt..gt] < a[gt+1..hi].
        sort(a, lo, lt-1, d);
        if (v >= 0) sort(a, lt, gt, d+1);
        sort(a, gt+1, hi, d);
    }

    private void insertion(String a, int lo, int hi, int d) {
       for (int i = lo; i <= hi; i++)
           for (int j = i; j > lo && less(a,j, j-1, d); j--)
               exch(j, j-1);
    }

    private boolean less(String s, int v, int w, int d) {

       for (int i = d; i < n + d; i++) {
           if (charAt(s,index[v], i) < charAt(s, index[w], i)) return true;
           if (charAt(s,index[v], i) > charAt(s, index[w], i)) return false;
       }
       return true;
   }

   private void exch(int i, int j) {
        int temp = index[i];
        index[i] = index[j];
        index[j] = temp;
    }

   private int charAt(String s, int suffix, int d) {
       assert d >= 0 && d <= s.length();
       if (d == s.length()) return -1;
       return s.charAt((suffix + d) % n);
    }

   // length of s
   public int length(){
       return input.length();
   }
   // returns index of ith sorted suffix
   public int index(int i){
       if(i < 0 || i >= length())throw new IllegalArgumentException();
       return index[i];
   }
   // unit testing (required)
   public static void main(String[] args){
       CircularSuffixArray c = new CircularSuffixArray("ABRACADABRA!");
       System.out.println("The length of String is: " + c.length());
       System.out.println("The index of String is: ");
       for(int i = 0 ; i < c.length();i++){
           System.out.print(c.index(i) + " ");
       }

   }
}
