import java.util.ArrayList;
import java.util.Scanner;

    
public abstract class BankMenu{
    
    private static final int ATTEMPTS_ALLOW = 4;
    private static final int LOG_IN = 1;
    private static final int SIGN_UP = 2;
    private static final int TERMINATE_ACCOUNT = 3;
    private static final int EXIT = 4;
    
    private static final int DEPOSIT_MONEY = 1;
    private static final int WITHDRAW_MONEY = 2;
    private static final int ACCOUNT_DETAILS = 3;
    
    private static final int CHANGE_FIRST_NAME = 1;
    private static final int CHANGE_LAST_NAME=2;
    private static final int CHANGE_ADDRESS = 3;
    private static final int CHANGE_USERNAME = 4;
    private static final int CHANGE_PIN = 5;
    private static final int EXIT_IN_ACCOUNTMENU = 6;
    
    
    public static Scanner terminal;
    //static methods
   
    
    
    public static void clearBuffer(Scanner in){
        if(in.hasNextLine()){
            in.nextLine();
        }
    }
    
    
    public static void landingMenu(Bank bank){
        
        boolean exit = false;
        System.out.println("Welcom to the greatest bank: "+bank.getName());
        
        while(!exit){
            System.out.println("");
            System.out.println(" -------Landing Menu---------");
            System.out.println("|  1. Log in                 |");
            System.out.println("|  2. Sign up                |");
            System.out.println("|  3. Terminate account      |");
            System.out.println("|  4. Exit                   |");
            System.out.println(" ----------------------------\n");
            System.out.print("Enter your choice of menu: ");
            
            int menuChoice = 0;
            try{
            
                menuChoice = terminal.nextInt();
                
            }catch(Exception ex){
                System.out.println("Please type in number!");
                continue;
            }finally{
                clearBuffer(terminal);
            }
            
            
            switch(menuChoice){
                case LOG_IN: loginMenu(bank);
                             break;
                case SIGN_UP: signupMenu(bank);
                             break;
                case TERMINATE_ACCOUNT: terminateAccountMenu(bank);
                             break;             
                case EXIT: exit = true; 
                             break;
                default: System.out.println("Invalid Input! try again!");
                         System.out.println("Usage: only numbers are accepted!");   
            }
             
        }//end of while
        
        System.out.println("Exiting successfully.......");
    }
   
    
    
   
   
    //behave: let user tries three times to login there account
    /*return: if user failed to enter correct pin and pin in three times
      it will return to previous menu*/
    
    public static void loginMenu(Bank bank){
        String userName = BankAccount.getValidUserNameFromUser(terminal,"user name");
        BankAccount matchAccount = bank.getAccount(userName);
        
        //check if user name exist, if not exist, return to previous menu
        if(matchAccount == null){
            System.out.println("Request is rejected!");
            return;
        }else{
            System.out.println("Login successfully");
            mainMenu(matchAccount,bank);
        }
        
        return;
        
    }
    
    
   
    
    
    /*behave: prompt user to set up a new account, if username has been
      registered,  reject user and return null*/
    //argument the bank in which users register new account
    //return: an bankaccount object if succeeds
    public static void signupMenu(Bank bank){
         
       
         
         //prompt user to enter user name to be registered, check if the 
         //user name exists, if it exists, print the message,return to previous menu
         String userName = BankAccount.getValidUserNameFromUser(terminal,
                                                       "user name to be registered");
         
         
         
         
         if(bank.accountExists(userName)){
             System.out.println("User name already exists, returning"
                                 +" to previous menu........");
             return;
         }
         
         
         //get user PIN , check if it is invalid
         int pin = BankAccount.getValidPINFromUser(terminal,"PIN");
      
           
         //get user first name , check if it is invalid
         String firstName = BankAccount.getValidNameFromUser(terminal,"first name");
         
         //get user last name , check if it is invalid
         String lastName = BankAccount.getValidNameFromUser(terminal,"last name");
         
         
         //get address
         System.out.println("Enter your address: ");
         String address = terminal.nextLine();
         
        
         //set up account
         BankAccount account = new BankAccount(firstName,lastName,userName,pin,
                                   address,0);
         
         bank.registerAccount(account);
         System.out.println("Registering you account successfully!");
         
         bank.printOut();
    
    }
    
    
    
    
    public static void terminateAccountMenu(Bank bank){
        
        String userName = BankAccount.getValidUserNameFromUser(terminal,
                                                       "user name to be terminated");
        if(bank.terminateAccount(userName)){
            System.out.println("Your account is terminated successfully");
        }else{
            System.out.println("Your request is rejected");
        }
        bank.printOut();
            
        return;   
    }
    
    public static boolean confirmYesOrNo(){
        System.out.println("Are you sure to terminate your account?[Y/N]");
        String yesOrNo = terminal.nextLine();
        yesOrNo = yesOrNo.toLowerCase();
            
        if(yesOrNo.equals("y")){
            return true;
        }else{
            return false;
        }
        
    }
    
    
    
    
    public static void mainMenu(BankAccount account,Bank bank){
        
        boolean exit = false;
        
        
        while(!exit){
            System.out.println("");
            System.out.println(" -------Main Menu---------");
            System.out.println("|  1. Deposit Money       |");
            System.out.println("|  2. Withdraw Money      |");
            System.out.println("|  3. Account Detail      |");
            System.out.println("|  4. Exit                |");
            System.out.println(" -------------------------\n");
            System.out.print("Enter your choice of menu: ");
            
            int menuChoice = 0;
            try{
            
                menuChoice = terminal.nextInt();
                
            }catch(Exception ex){
                System.out.println("Please type in choiece in number!");
                continue;
            }finally{
                clearBuffer(terminal);
            }
            
            
            switch(menuChoice){
                case DEPOSIT_MONEY:   depositMenu(account);
                             break;
                case WITHDRAW_MONEY:  withdrawMenu(account);
                             break;
                case ACCOUNT_DETAILS: accountMenu(account,bank);
                             break;             
                case EXIT: exit = true; 
                             break;
                default: System.out.println("Invalid Input! try again!");
                         System.out.println("Usage: only numbers are accepted!");
                            
            }
            
        }
        
        System.out.println("Exiting successfully.......");
    }
    
    
    
    public static void depositMenu(BankAccount account){
       
        System.out.println("Please enter the amount of money to deposit: ");
        int amount=0;
       
      
        try{
            amount = terminal.nextInt();
            account.addBalance(amount);
            System.out.println("request processed successfully!");
        }catch(NumberIsNegative ex){
                System.out.println(ex.getMessage());
        }catch(Exception ex){
                System.out.println("Invalid Input");
        }finally{
            clearBuffer(terminal);
        }
        
    }
    
    public static void withdrawMenu(BankAccount account){
        System.out.println("Please enter the amount of money to withdraw: ");
        int amount=0;
       
      
        try{
            amount = terminal.nextInt();
            account.subtractBalance(amount); 
            System.out.println("request processed successfully!");
        }catch(NumberIsNegative ex){
                System.out.println(ex.getMessage());
        }catch(NumberIsOverLimit ex){
                System.out.println(ex.getMessage());
        }catch(Exception ex){
                System.out.println("Invalid Input");
        }finally{
            clearBuffer(terminal);
        }

             
    }
    
    public static void accountDetail(BankAccount account){
        System.out.println("");
        System.out.println("--------------Account Info-----------------");
        System.out.println("    User name :  "+account.getUserName());
        System.out.println("    First name:  "+account.getFirstName());
        System.out.println("    Last name :  "+account.getLastName());
        System.out.println("    Address   :  "+account.getAddress());
        System.out.println("    Balance   :  "+account.getBalance());
        System.out.println("-------------------------------------------\n\n");
            
            
    }
    public static void accountMenu(BankAccount account,Bank bank){
        
        boolean exit = false;
        while(!exit){
            accountDetail(account);
            System.out.println("");
            System.out.println(" ---------Account Menu---------");
            System.out.println("|  1. Change First Name        |");
            System.out.println("|  2. Change Last Name         |");
            System.out.println("|  3. Change Address           |");
            System.out.println("|  4. Change UserName          |");
            System.out.println("|  5. Change PIN               |");
            System.out.println("|  6. Exit                     |");
            System.out.println(" ------------------------------\n");
            System.out.print("Enter your choice of menu: ");
            
            int menuChoice = 0;
            
            try{
            
                menuChoice = terminal.nextInt();
                
            }catch(Exception ex){
                System.out.println("Invalid input! Try again!");
                continue;
            }finally{
                clearBuffer(terminal);
            }
            
            
            switch(menuChoice){
                case CHANGE_FIRST_NAME:   changeFirstNameMenu(account);
                                          break;
                case CHANGE_LAST_NAME:  changeLastNameMenu(account);
                                        break;
                case CHANGE_ADDRESS: changeAddressMenu(account);
                                     break;             
                case CHANGE_USERNAME: changeUserNameMenu(account,bank);
                                      break;
                case CHANGE_PIN: changePINMenu(account);
                                 break;          
                case EXIT_IN_ACCOUNTMENU: exit = true;
                                          break;           
                default: System.out.println("Invalid Input! try again!");
                         System.out.println("Usage: only numbers are accepted!");
                            
            }
            
        }
        
        System.out.println("Exiting successfully.......");
    }
   
    
    
    
    
    public static void changeFirstNameMenu(BankAccount account){
        
        String firstName;
        boolean request;
        request = confirmAccountPIN(account);
        if(request==false){
            return;
        }else{
            firstName = BankAccount.getValidNameFromUser(terminal,"New first name");
        }
        System.out.println("update first name successfully!");
        account.setFirstName(firstName);
        
        
        
    }
    public static void changeLastNameMenu(BankAccount account){
        String lastName;
        boolean request;
        request = confirmAccountPIN(account);
        if(request==false){
            System.out.println("request failed!");
            return;
        }else{
            lastName = BankAccount.getValidNameFromUser(terminal,"New last name");   
        }
        
        account.setlastName(lastName);
        System.out.println("update last name successfully!");
    }
    
    
    public static void changeAddressMenu(BankAccount account){
        String address=null;
        boolean request;
        request = confirmAccountPIN(account);
        if(request==false){
            System.out.println("request failed!");
        }else{
            System.out.println("Enter your New address: ");
            address = terminal.nextLine();
        }
        
        account.setAddress(address);
        System.out.println("update address successfully!");
        
    }
    
    
    public static void changeUserNameMenu(BankAccount account,Bank bank){
        String userName;
        boolean request;
        request = confirmAccountPIN(account);
        if(request==false){
            System.out.println("request failed!");
            return;
        }else{
            userName = BankAccount.getValidUserNameFromUser(terminal,"New user name");
            BankAccount matchAccount = bank.getAccount(userName);
            if(matchAccount!= null){
                System.out.println("user name already exists, request failed!");
                return;
            }
        }
        
        account.setUserName(userName);
        System.out.println("update username successfully!");
    }
    
    
    public static void changePINMenu(BankAccount account){
        int pin;
        boolean request;
        request = confirmAccountPIN(account);
        if(request==false){
            System.out.println("request failed!");
            return;
        }else{
            pin = BankAccount.getValidPINFromUser(terminal,"New PIN");   
        }
        
        account.setPIN(pin);
        System.out.println("update PIN successfully"); 
    }
    
    
    
    /*behave: prompt user to confirm pin,user has specific times chance to confirm*/
    //argument: account that is needed to confirm
    //return false if user failed to confirm, true otherwise
    
    public static boolean confirmAccountPIN(BankAccount account){
        int pin;
        int attempts = ATTEMPTS_ALLOW;
        System.out.println("Current account: "+ account.getUserName());
        pin = BankAccount.getValidPINFromUser(terminal,"PIN");
        
        while(pin != account.getPIN()){
            if (attempts == 0){
                System.out.println("You have no more chance to confirm");
                return false;
            }
            System.out.println("PIN entered is wrong!");
            System.out.println("Try again, enter your PIN: ");
            pin = BankAccount.getValidPINFromUser(terminal,"PIN");
            attempts--;
        }
        
        return true;    
        
    }

}


