import java.util.Scanner;
public class Main{
     public static void main(String[] args){
        BankMenu.terminal = new Scanner(System.in);
        Bank bank1 = new Bank("AMERICAN BANK");
        BankMenu.landingMenu(bank1);
        BankMenu.terminal.close();
        
    }
}