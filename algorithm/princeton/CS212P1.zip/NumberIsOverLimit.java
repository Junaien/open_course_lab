public class NumberIsOverLimit extends Exception{
    public NumberIsOverLimit(String message){
        super(message);
    }
}