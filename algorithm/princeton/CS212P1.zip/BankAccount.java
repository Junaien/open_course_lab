import java.util.Scanner;
import java.util.NoSuchElementException;
class BankAccount {
    
    //Fields
    private String firstName;
    private String lastName;
    private String address;
    private String userName;
    private int pin;
    private int balance;
    
    /*
    public static void main(String[] args){
        Scanner terminal = new Scanner(System.in);
        String a = terminal.next();
        System.out.println(isValidName(a));
        
        int b = terminal.nextInt();
        System.out.println(isValidPIN(b));
    }*/
    

    //constructor
    public BankAccount(String firstName,String lastName,String userName,int pin){
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.pin = pin;
        address = " ";
        balance = 0;
    }
    

    public BankAccount(String firstName,String lastName,String userName,int pin,
                          String address,int balance){
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.pin = pin;
        this.address = address;
        this.balance = balance;
    }
    
    //copy constructor
    public BankAccount(BankAccount other){
        this.firstName = other.firstName;
        this.lastName = other.lastName;
        this.userName = other.userName;
        this.pin = other.pin;
        this.address = other.address;
        this.balance = other.balance;
    }
    
    
    
    //public
    //static method
    
    
    //behavior:check if the name passed in only contains letter
    //argument: String to be checked
    //return: true if string only contains characters,false otherwise
    public static boolean isValidName(String name){
       
        char[] chars =  name.toCharArray();
        
        for(char c: chars){
            if(!Character.isLetter(c) && c != '-' && c !=' ')
                return false;
            
        }
        
        return true;
    }
    
    //behavior:  check if the name passed in only contains letter and numbers 
    //argument:  String to be checked
    //return:    true if string only contains characters,false otherwise
    public static boolean isValidUserName(String userName){
        
        char[] chars =  userName.toCharArray();
        for(char c: chars){
            if(!Character.isLetter(c) && !Character.isDigit(c))
                return false;
        }
        return true;
    }
    
    
    
    //behavior:  check if PIN number contains only 4 digits
    //argument: integer pin to be check
    //return: true if integer contains only 4 digits
    public static boolean isValidPIN(int pin){
        if(pin>=1000 && pin <=9999){
            return true;
        }else{
            return false;
        }
    }
    
    
    
    /*behavior:  this function gurranttes to return a valid name 
                 prompt user to enter a valid name until they do
                 if user enter invalid input, print the useage rule*/    
    //argument:  what to enter
    //return:    a valid name
    public static String getValidNameFromUser(Scanner in,String whatToEnter){
        System.out.println("Enter your "+ whatToEnter+":");
        String validName ="letters";
        boolean exit = false;
        while(!exit){
            
            
            try{
                validName = in.next();
                if(!isValidName(validName)){
                    System.out.println("Invalid "+ whatToEnter+"!");
                    System.out.println("\nUsage: only letters are accepted!");
                    continue;
                }
                exit = true;
            }catch(Exception ex){
                System.out.println("Invalid Input!");
                System.out.println("\nUsage: only letters are accepted!");
                continue;
            }finally{
                BankMenu.clearBuffer(in);        
            }
        
        }
        return validName;
        
        
    }
    
    
    
    /*behavior:  prompt user to enter a valid username until they do
                 if user enter invalid input, print the useage rule*/ 
    //return:  a valid username
    public static String getValidUserNameFromUser(Scanner in,String whatToEnter){
        System.out.println("Enter your "+ whatToEnter+":");
        String validUserName ="lettersORnumbers";
        boolean exit = false;
        while(!exit){
        
            try{
                validUserName = in.next();
                if(!isValidUserName(validUserName)){
                    System.out.println("Invalid "+ whatToEnter+"!");
                    System.out.println("\nUsage: only letters and numbers are accepted!");
                    continue;
                }
                exit = true;
            }catch(Exception ex){
                System.out.println("Invalid "+ whatToEnter+"!");
                System.out.println("\nUsage: only letters and numbers are accepted!");
                continue;
            }finally{
                BankMenu.clearBuffer(in);        
            }
        
        }
        return validUserName;
    }
    
    
    
    /*behavior:  prompt user to enter a valid PIN until they do
                 if user enter invalid input, print the useage rule*/ 
    //return:  a valid PIN
    public static int getValidPINFromUser(Scanner in,String whatToEnter){
        System.out.println("Enter your "+ whatToEnter+":");
        int validPIN = 1994;
        boolean exit = false;
        while(!exit){
        
            try{
                validPIN = in.nextInt();
                if(!isValidPIN(validPIN)){
                    System.out.println("Invalid "+ whatToEnter+"!");
                    System.out.println("\nUsage: only 4-digit number are accepted!");
                    continue;
                }
                exit = true;
            }catch(Exception ex){
                System.out.println("Invalid "+ whatToEnter+"!");
                System.out.println("\nUsage: only 4-digit number are accepted!");
                continue;
            }finally{
                BankMenu.clearBuffer(in);        
            }
        
        }
        return validPIN;
    }
    
    
    //public
    //instance method
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public String getAddress(){
        return address;
    }
    public int getBalance(){
        return balance;
    }
    public String getUserName(){
        return userName;
    }
    public int getPIN(){
        return pin;
    }
    
    
    
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    public void setlastName(String lastName){
        this.lastName = lastName;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public void setBalance(int balance){
        this.balance = balance;
    }
    public void setUserName(String userName){
        this.userName = userName;
    }
    public void setPIN(int pin){
        this.pin= pin;
    }
    
    
    public void addBalance(int amount) throws NumberIsNegative{
        if(amount<0)
            throw new NumberIsNegative("Number can't be negative!");
        balance = balance + amount;
    }
    
    public void subtractBalance (int amount)throws NumberIsNegative   
                                            ,NumberIsOverLimit{
        if(amount<0)
            throw new NumberIsNegative("Number can't be negative!");
        if(amount>balance)
            throw new NumberIsOverLimit("Amount number is over deposit limit!");
        
        balance = balance - amount;
    }
    
   
    
}

