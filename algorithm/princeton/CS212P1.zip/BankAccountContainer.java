import java.util.NoSuchElementException;

public class BankAccountContainer{
    //static variable
    private static final double GROW_RATE= 2.0;
    private static final double SHRINK_RATE=0.5;
    private static final double SHRINK_INDICATOR = 0.25;
    private static final int DEFAULT_CAPACITY = 2;
    
    
    //field
    private BankAccount[] bankAccountHolder;
    private int holderSize=0;
   
    
    // constructor
    public BankAccountContainer(){
        bankAccountHolder = new BankAccount[DEFAULT_CAPACITY];
        
    }
    public BankAccountContainer(int length)throws NumberIsNegative{
        if (length <= 0){
            throw new NumberIsNegative("Container size can't be negative");
        }
        
        bankAccountHolder = new BankAccount[length];
        
    }
    
    
    
    //private methods------------------------------------------------------
    
    //query part
    
    //return -1 if account not found
    private int findBankAccount(BankAccount target){
        for(int i = 0; i<holderSize;i++){
            if (bankAccountHolder[i].getUserName()==target.getUserName())
                return i;
        }
        return -1;
    }
    
    private boolean isFull(){
        if(holderSize >= bankAccountHolder.length){
            return true;
        }else{
            return false;
        }
             
    }
    private boolean isEmpty(){
        if(holderSize==0){
            return true;
        }else{
            return false;
        }
    }
    
    
    private boolean isTimeToShrinkContainer(){
//        if(bankAccountHolder.length <= DEFAULT_CAPACITY){
//            return false;
//        }
        
        if(holderSize <= (int)( bankAccountHolder.length * SHRINK_INDICATOR)){
            return true;
        }else{
            return false;
        }
    }
    
    
    
    
    

    //update part
    private void setBankAccountHolder(BankAccount[] bankAccountHolder){
        this.bankAccountHolder = bankAccountHolder;
    }
    
    private void incrementAccountSize(){
        holderSize++;
    }
    private void decrementAccountSize(){
        holderSize--;
    }
    
    private void growContainer(){
        
        int length = bankAccountHolder.length;
        length *= GROW_RATE;
        BankAccount[] temp = new BankAccount[length];
        System.arraycopy(bankAccountHolder,0,temp,0,holderSize);
        bankAccountHolder = temp;

    }
    
    private void shrinkContainer(){
        int length = bankAccountHolder.length;
        length = (int)(length*SHRINK_RATE);
        BankAccount[]temp = new BankAccount[length];
        
        int size = holderSize;
        System.arraycopy(bankAccountHolder,0,temp,0,size);
        bankAccountHolder = temp;
        
    }
    
    
    
    
    //public methods--------------------------------------------------
    //query part
    public int getHolderCapacity(){
        return bankAccountHolder.length;
    }
    public int getHolderSize(){
        return holderSize;
    }
    
    public BankAccount get(int i){
        return bankAccountHolder[i];
    }
    
    
    //update part
    public void add(BankAccount account){
        if(isFull()){
            growContainer();
        }
        
        bankAccountHolder[holderSize] = account; 
        incrementAccountSize();
        
    } 
    
    public void remove(BankAccount account)throws NoSuchElementException{
        int targetIndex = findBankAccount(account);
        if(targetIndex == -1)
            throw new NoSuchElementException("element not found!");
        int i;
        
        for(i=(targetIndex+1); i<holderSize;i++){
            bankAccountHolder[i-1]= bankAccountHolder[i];
        }
        bankAccountHolder[i-1]=null;
        decrementAccountSize();
        if(isTimeToShrinkContainer()){
            shrinkContainer();
        }
        
    }
    
    
}