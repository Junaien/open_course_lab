import java.util.ArrayList;
class Bank{
   
    //fields
    private BankAccountContainer accounts = new BankAccountContainer();
    private String name;
    
    
    //constructor
    public Bank(String bankName){
        name = bankName;
    }
    //copy constructor
    public Bank(Bank other){
        name = other.name;
        for(int i = 0; i<other.accounts.getHolderSize();i++){
            BankAccount copyAccount = new BankAccount(other.accounts.get(i));
            accounts.add(copyAccount);
        }
    }
    
    
    //public
    //query 
    public String getName(){
        return name;
    }
    
    
    
    //behave:    check if account exists
    //argument:  username string
    //return:    true if account exsists otherwise false
    public boolean accountExists(String userName){
         for (int i = 0; i< accounts.getHolderSize();i++){
            if(accounts.get(i).getUserName().equals(userName)){
                    return true;
            }
         }
         return false;
    }
    
    
    
    /*behave: inputs pin for matching accounts, finding out if
              pin is correct for this username*/
    //arguments: username and password
    /*return:    account object if the pin matches username
                 null if account not found or pin match failure*/ 
    public BankAccount getAccount(String userName){
         
         for(int i = 0; i< accounts.getHolderSize();i++){
             BankAccount account = accounts.get(i);
             if(account.getUserName().equals(userName)){
                 if(BankMenu.confirmAccountPIN(account)){
                     return account;
                 }else{
                     return null;
                 }
                           
            }
         }
         
         System.out.println("Sorry!  Account is not exist!");
         return null;
    }

    
    
    /*behave:   add an account object to bank, check duplicate username 
                in BankMenu method*/
    //argument: bankaccount object needs to register
    public void registerAccount(BankAccount account){
        
       accounts.add(account); 
       
    }
    
    
    
    
    /*behave:    terminate accounts */
    //argument:  username and corresponding
    //return:    return true if it terminates successfully, otherwise false 
    public boolean terminateAccount(String userName){
        
        for(int i = 0; i< accounts.getHolderSize();i++){
             BankAccount account = accounts.get(i);
             if(account.getUserName().equals(userName)){
                 if(BankMenu.confirmAccountPIN(account)){
                     if(BankMenu.confirmYesOrNo()){
                         accounts.remove(account);
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
                           
            }
         }
         System.out.println("Sorry!  Account does not exist!");
         return false; 
    }
    
    
    public void printOut(){
         System.out.println("------Bank current information for debuging------");
         System.out.println("\n    AccountHolderCapacity: " + accounts.getHolderCapacity());
         System.out.println("    AccountHolderSize: " + accounts.getHolderSize());
         System.out.println("    User:");
         for(int i = 0; i< accounts.getHolderSize();i++){
             BankAccount account = accounts.get(i);
             System.out.print("    ");
             System.out.println((i+1) +": "+ account.getUserName());
           
         }
         System.out.println("-------------------------------------------------\n");
    }
  
}

