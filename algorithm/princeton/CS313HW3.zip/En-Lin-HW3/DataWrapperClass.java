
import java.util.*;
import java.io.File;

public class DataWrapperClass {
	public int num_data;		// number of data (N)
	public int num_features;	// number of features (D)
	public int num_classes;		// number of different classes (K)
	public int num_cont_fea; 	// number of continuous features
	public int num_cat_fea;		// number of categorical features
	public ArrayList<ArrayList<Double> > continuous_features;	// only continuous features
	public ArrayList<ArrayList<Integer> > categorical_features;	// only categorical features
	public ArrayList<Integer> labels;	// labels of all data

	// read features and labels from input files
	public DataWrapperClass(String feature_fname, String label_fname){
		// FILL IN
		// read feature and label file
		// store feature in continuous_/categorical_features,
		// store labels
		// if file name starts with 'CAT_', all features are categorical
		// otherwise, all features are continuous
		Scanner scD = null;
		Scanner scL = null;
		num_classes = 0;
		String[] temps = null;

		try{

		  File f = new File(feature_fname);
		  String fname = f.getName();
          scD = new Scanner(f);
 	  	  scL = new Scanner(new File(label_fname));
          labels = new ArrayList<Integer>();
		  continuous_features = new ArrayList<ArrayList<Double>>();
		  categorical_features = new ArrayList<ArrayList<Integer>>();


		  while(scL.hasNextLine() && scD.hasNextLine()){
              int label = scL.nextInt();
			  if(label + 1 > num_classes)num_classes = label+1; //update number of classes
		      labels.add(label);

			  temps = (scD.nextLine().trim()).split("\\s+");
			  num_features = temps.length;

			  if(fname.startsWith("CAT_")){
                //all files are categorical
	          	ArrayList<Integer> features = new ArrayList<Integer>();
	            for(int i = 0; i<num_features; i++){
					features.add(Integer.parseInt(temps[i]));
				}
				categorical_features.add(features);
				num_cont_fea = 0;
				num_cat_fea = num_features;

			  }else{
				  //all files are continuous
		          ArrayList<Double> features = new ArrayList<Double>();
				  for(int i = 0; i<num_features;i++){
					  features.add(Double.parseDouble(temps[i]));
				  }
				  continuous_features.add(features);
                  num_cont_fea = num_features;
				  num_cat_fea = 0;
			  }

			  num_data++;  //update data number

		  }
		// System.out.println("Good Here");


		}catch(Exception e){
			System.out.println("Something is wrong in DataWrapperClass");
			return;
		}

	}
    public void print(){
		System.out.println("feature:");
	    for(int i = 0 ; i < continuous_features.size(); i++){
		    for(int j = 0; j < continuous_features.get(0).size(); j++){
				System.out.print(continuous_features.get(i).get(j)+ " ");
			}
			System.out.println();
		}

		for(int i = 0 ; i < categorical_features.size(); i++){
		    for(int j = 0; j < categorical_features.get(0).size(); j++){
				System.out.print(categorical_features.get(i).get(j)+ " ");
			}
			System.out.println();
		}

		System.out.println("label:");

	    for(int j = 0; j < labels.size(); j++){
			System.out.print(labels.get(j)+ " ");
			System.out.println();
		}
		System.out.println();

	}
	public static void main(String[] args){
		DataWrapperClass w = new DataWrapperClass(args[0], args[1]);
		w.print();
	}
	// static function, compare two label lists, report how many are correct
	public static int evaluate(ArrayList<Integer> l1, ArrayList<Integer> l2){
		int len = l1.size();
		assert len == l2.size();	// length should be equal
		assert len > 0;				// length should be bigger than zero
		int ct = 0;
		for(int i = 0; i < len; ++i){
			if(l1.get(i).equals(l2.get(i))) ++ct;
		}
		return ct;
	}

	// static function, compare two label lists, report score (between 0 and 1)
	public static double accuracy(ArrayList<Integer> l1, ArrayList<Integer> l2){
		int len = l1.size();
		assert len == l2.size();	// label lists should have equal length
		assert len > 0;				// lists should be non-empty
		double score = evaluate(l1,l2);
		score = score / len;		// normalize by divided by the length
		return score;
	}
}
