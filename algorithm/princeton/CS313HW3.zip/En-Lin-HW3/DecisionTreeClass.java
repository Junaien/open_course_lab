import java.util.*;

public class DecisionTreeClass {
	private static class DecisionTreeNode implements Comparable<DecisionTreeNode>{
		public HashMap<Integer,int[]> optSplitInformation;
		public HashMap<Integer, ArrayList<Integer>> optSplitIDs;
		public ArrayList<Integer> data_list; // list of data IDs
		public int opt_fea_type = -1;	// 0 if continuous, 1 if categorical
		public int opt_fea_id = -1;		// the index of the optimal feature
		public double opt_fea_thd = Double.NEGATIVE_INFINITY;	// the optimal splitting threshold
															// for continuous feature
		public int opt_improvement = -1; // the improvement if split based on the optimal feature
		public boolean is_leaf = true;		// is it a leaf
		public int majority_class = -1;		// class prediction based on majority vote
		public int num_accurate = -1;		// number of accurate data using majority_class
		public DecisionTreeNode parent = null;		// parent node
		public ArrayList<DecisionTreeNode> children; 	// list of children when split
		public int featureValue = -1; //what is this node's feature value based on parent's split
		public int height = 0;


        //compare opt_improvement for PriorityQueue to work
        public int compareTo(DecisionTreeNode n){
			Integer a = new Integer(this.opt_improvement);
			Integer b = new Integer(n.opt_improvement);
			return b.compareTo(a);
		}

		public DecisionTreeNode(ArrayList<Integer> d_list, int m_class, int n_acc){
			data_list = new ArrayList<Integer>(d_list);
			majority_class = m_class;
			num_accurate = n_acc;
		}
	}

	public DataWrapperClass train_data;
	public int max_height;
	public int max_num_leaves;
	public int height = 1;
	public int num_leaves = 1;
	public DecisionTreeNode root;

    //comparator for ID to sort by continuous_feature values
	private class featureComparator implements Comparator<Integer>{
		public int featureIndex;
		public DataWrapperClass train_data;
		public featureComparator(int featureIndex, DataWrapperClass train_data){
			this.featureIndex = featureIndex;
			this.train_data = train_data;
		}

		public int compare(Integer ID1, Integer ID2){
            Double lhs = train_data.continuous_features.get(ID1).get(featureIndex);
			Double rhs = train_data.continuous_features.get(ID2).get(featureIndex);
			return lhs.compareTo(rhs);




		}
	}

	/**
     * calculate the imformation after split with featureIndex
     *
     * @param  int                     featureIndex  the feature Index to split
     * @param  int                     numClasses    how many kind of labels there
     * @param  ArrayList<Integer>      ID            the id with regard to original one
     * @param  HashMap<Integer,int[]>  splitInformation contains majority class and number of it
     * @param  double[]                thd           threshold
     * @param  int                     curAccuracy   the accuracy before split
     * @return                                  return a map that contains ID set split
     *                                          by this feature,  return null if ID has size 0;
     *                                          return null if has no accuracy improved;
     */
    private HashMap<Integer, ArrayList<Integer>> accuracyWithContinuousFeature(int featureIndex,
			int numClasses, ArrayList<Integer> ID, HashMap<Integer, int[]> splitInformation,
			double[] thd, int curAccuracy)
	{
        if(ID.size() <= 1)return null;
		//initialize
		splitInformation.put(0,new int[2]);
		splitInformation.put(1,new int[2]);
		HashMap<Integer, ArrayList<Integer>> splitIDs = new HashMap<>();
        splitIDs.put(0,new ArrayList<Integer>());
		splitIDs.put(1,new ArrayList<Integer>());

		//sort current IDs by this feature
        Collections.sort(ID, new featureComparator(featureIndex,train_data));

		int threshold = findOptThreshold(ID, splitInformation, curAccuracy, numClasses);
        // int threshold = findOptThresholdNaive(ID, splitInformation, curAccuracy, numClasses);

        if(threshold == -1)return null;
        int id = ID.get(threshold);
		thd[0] = train_data.continuous_features.get(id).get(featureIndex);
        //put id into two sets
		for(int i = 0; i< ID.size();i++){
            if(i <= threshold){
				splitIDs.get(0).add(ID.get(i));
			}else{
				splitIDs.get(1).add(ID.get(i));
			}
		}
		return splitIDs;
	}

    //
	private int findOptThresholdNaive(ArrayList<Integer> ID,
	HashMap<Integer, int[]> splitInformation, int curAccuracy, int numClasses){
        if(ID.size() <= 1)return -1;
    	int threshold = -1;
		int curOptAccuracy = curAccuracy;
		for(int i = 0 ; i< ID.size(); i++){
		    int tempAccuracy = accuracyOnThisThreshold(i, ID, curOptAccuracy,
			splitInformation, numClasses);
			if(tempAccuracy != -1){
				curOptAccuracy = tempAccuracy;
				threshold = i;
			}
		}
		return threshold;
	}

    private int accuracyOnThisThreshold(int index, ArrayList<Integer> ID,
	int optAccuracy, HashMap<Integer, int[]> splitInformation, int numClasses){
        int[] labelCountLE = new int[numClasses+2];
		int[] labelCountR = new int [numClasses+2];
		for(int i = 0; i < ID.size(); i++){
            int label = train_data.labels.get(ID.get(i));

			//index is intended threshold array Index
			if(i <= index){
				labelCountLE[label]++;
			}else{
				labelCountR[label]++;
			}
		}
		    int majorityR = -1;
			int majorityL = -1;
			updateAccuracyAndClass(labelCountR);
			updateAccuracyAndClass(labelCountLE);
			majorityL = labelCountLE[numClasses];
			majorityR = labelCountR[numClasses];

			if(majorityL + majorityR > optAccuracy){
				(splitInformation.get(0))[0] = majorityL;
				(splitInformation.get(1))[0] = majorityR;
				(splitInformation.get(0))[1] = labelCountLE[numClasses+1];
				(splitInformation.get(1))[1] = labelCountR[numClasses+1];
                return majorityL + majorityR;
			}else{
				return -1;
			}
	}

	//find opt_fea_thd in one pass
    private int findOptThreshold(ArrayList<Integer> ID,
	HashMap<Integer, int[]> splitInformation, int curAccuracy, int numClasses){

		int[] labelCountLE = new int[numClasses+2];
		int[] labelCountR = new int[numClasses+2];
        int majorityL = 0;
		int majorityR = 0;
        int threshold = -1;
		int optAccuracy = curAccuracy;

		//initialize labelCountR
        for(int i = 0; i< ID.size();i++){
			int label = train_data.labels.get(ID.get(i));
			labelCountR[label]++;
		}
		//calculate opt threshold and optAccuracy
		for(int i = 0; i < ID.size(); i++){

            int label = train_data.labels.get(ID.get(i));
			labelCountLE[label]++;
			labelCountR[label]--;
			updateAccuracyAndClass(labelCountR);
			updateAccuracyAndClass(labelCountLE);
			majorityL = labelCountLE[numClasses];
			majorityR = labelCountR[numClasses];

			if(majorityL + majorityR > optAccuracy){
				optAccuracy = majorityL + majorityR;
				threshold = i;
				(splitInformation.get(0))[0] = majorityL;
				(splitInformation.get(1))[0] = majorityR;
				(splitInformation.get(0))[1] = labelCountLE[numClasses+1];
				(splitInformation.get(1))[1] = labelCountR[numClasses+1];

			}
		}
		return threshold;
	}


	private HashMap<Integer, ArrayList<Integer>> accuracyWithCategoricalFeature(int featureIndex, int numClasses,
		ArrayList<Integer> ID, HashMap<Integer, int[]>splitInformation ){

		if(ID.size() <= 1)return null;
		HashMap<Integer, ArrayList<Integer>> splitIDs = new HashMap<>();

        for(int i = 0; i < ID.size(); i++){
			int id = ID.get(i);

			int featureValue = (train_data.categorical_features.get(id)).get(featureIndex);

			if(splitInformation.containsKey(featureValue)){
				int[] classCount = splitInformation.get(featureValue);
				int label = train_data.labels.get(id);
				classCount[label]++;
                splitIDs.get(featureValue).add(id);

			}else{
				int[] classCount = new int[numClasses+2];
				int label = train_data.labels.get(id);
				classCount[label]++;
				splitInformation.put(featureValue,classCount);
				ArrayList<Integer> tmp = new ArrayList<Integer>();
				tmp.add(id);
				splitIDs.put(featureValue,tmp);
			}

		}
		for(int[] i : splitInformation.values()){
            updateAccuracyAndClass(i);
		}
		return splitIDs;
	}

	private static int calculateTotalAccuracy(HashMap <Integer, int[]> splitInformation){
		if(splitInformation == null)return -1;
		int totalAccuracy = 0;
	    for(int[] i : splitInformation.values()){
            totalAccuracy += i[i.length-2];
		}
		return totalAccuracy;
	}

	private static void updateAccuracyAndClass(int[] labelCount){
		labelCount[labelCount.length -2] = -1;
		for(int i = 0; i < labelCount.length - 2;i++){
			if(labelCount[i] > labelCount[labelCount.length-2]){
				labelCount[labelCount.length-2] = labelCount[i];
				labelCount[labelCount.length-1] = i;
			}
		}
	}

	// constructor, build the decision tree using train_data, max_height and max_num_leaves
	public DecisionTreeClass(DataWrapperClass t_d, int m_h, int m_n_l){
		train_data = t_d;
		max_height = m_h;
		max_num_leaves = m_n_l;
        // System.out.println("how many data there? " + train_data.num_data);
        PriorityQueue<DecisionTreeNode> q = new PriorityQueue<>();

		// FILL IN
		// create the root node, use all data_ids [0..N-1]
		// find the majority class, also how many accurate using the majority class
		// if the majority class is correct for all data,
		//		no improvement possible
		// 		the optimal accuracy improvement = 0
		// else
		//		find the optimal feature to split
		// 		for each feature
		//			if categorical
		//			  	split the data_list into sub-lists using different values of the feature
		//				for each sub-list
		//					find the majority class
		//					compute the number of accurate prediction using this majority class
		//				sum up number of accurate predictions for all sub-lists as the score
		//			if continuous
		//				sort the data based on the continuous feature
		//				find the optimal threshold to split the data_list into two sub-lists
		//				for each of sub-list
		//					find the majority class
		//					compute the number of accurate prediction using this majority class
		//				sum up number of accurate predictions for all sub-lists as the score
		// 		find the feature with the largest score (best total num of accurate prediction after splitting)
		// 		optimal accuracy improvement = the difference between the best total num of accurate prediction after splitting
		//								and the number of accurate prediction using the majority class of the current node
		// put the root node and the optimal accuracy improvement into a max-heap
		//
        ArrayList<Integer> dataList = new ArrayList<>();
		int[] classCount = new int[train_data.num_classes];
		int majorityClass = 0;

		for(int i = 0; i < train_data.num_data; i++){
			int label = train_data.labels.get(i);
			classCount[label]++;
            if(classCount[label] > classCount[majorityClass]) majorityClass = label;
			dataList.add(i);
		}

		// System.out.println("This is the overview of root");
		// for(int i = 0; i<classCount.length; i++){
		// 	System.out.println("Label" + i + ": " + classCount[i]);
        //
		// }
		root = new DecisionTreeNode(dataList, majorityClass, classCount[majorityClass]);
        if(root.num_accurate == train_data.num_data)return;
        this.optProcess(root);
        q.add(root);
		// while the heap is not empty
		// 		extract the maximum entry (the leaf node with the maximal optimal accuracy improvement) from the heap
		//		if the optimal accuracy improvement is zero (no improvement possible)
		//			break;
		//		else
		//			split the node
		//			create children based on the optimal feature and split (each sub-list creates one child)
		//			for each child node
		//				find its optimal accuracy improvement (and the optimal feature) (as you do for the root)
		//				put the node into the max-heap
		//		if the number of leaves > max_num_leaves
		//			break;
		//		if the height > max_height
		//			break;
		//
        while(q.size()!=0){
			// for(DecisionTreeNode k: q){
			// 	System.out.print(k.opt_improvement + "/");
			// }
			// System.out.print("leaves: " + num_leaves + "/height: " + height+"/");

			DecisionTreeNode optNode = q.poll();
			// System.out.println("cur imporvement: " + optNode.opt_improvement);
            // for(DecisionTreeNode i: q){
			// 	System.out.print( i.opt_improvement+"-"+ "\n");
			// }
			//todo list update the height and leaves
			// System.out.println("Here is good");
			if(num_leaves > max_num_leaves)break;
			if(height > max_height)break;
			if(optNode.opt_improvement <= 0)break;
            splitThisNode(optNode, q);
		}


	}

    private void splitThisNode(DecisionTreeNode n,
		PriorityQueue<DecisionTreeNode>q)
	{

		n.is_leaf = false;
		n.children = new ArrayList<DecisionTreeNode>();
		for(Integer i : n.optSplitIDs.keySet()){
			ArrayList<Integer> dataList = n.optSplitIDs.get(i);
			int[] labelCount = n.optSplitInformation.get(i);
			int l = labelCount.length;
            DecisionTreeNode newNode = new DecisionTreeNode(dataList,
				labelCount[l-1], labelCount[l-2]);

			newNode.featureValue = i;
			newNode.parent = n;
            newNode.height = n.height+1;
			if(newNode.height>height)height = newNode.height;

			optProcess(newNode);
			n.children.add(newNode);
			// System.out.println(newNode.num_accurate + "/" + newNode.data_list.size());
			q.add(newNode);
			num_leaves++;
		}
		num_leaves--;
	}

    /**
     * process a decision node to determine the optimal feature to split
     * @param DecisionTreeNode n  node to split
     */

    private void optProcess(DecisionTreeNode n){

		// if all data is homogeneous no imporvement possible
        if(n.num_accurate == n.data_list.size()){
			n.opt_improvement = -1;
		}

		//decide opt features
		boolean cat = true;
		if(train_data.num_cat_fea == 0)cat = false;
		HashMap<Integer, ArrayList<Integer>> splitIDs = null;

        for(int i = 0; i < train_data.num_features; i++){

            if(cat){
				if(n.parent!= null && n.parent.opt_fea_id == i)continue;
				HashMap<Integer, int[]> splitInformation = new HashMap<>();
				splitIDs = this.accuracyWithCategoricalFeature(i,
					train_data.num_classes,n.data_list,splitInformation);

                if(splitIDs == null)continue;
				int totalAccuracy = DecisionTreeClass.calculateTotalAccuracy(splitInformation);
				// System.out.println("Total accuracy: " + totalAccuracy+
				// "before split accuracy: " + n.num_accurate);
				if(totalAccuracy-n.num_accurate > n.opt_improvement){
				    n.opt_improvement = totalAccuracy-n.num_accurate;
					n.opt_fea_type = 1;
					n.optSplitInformation = splitInformation;
					n.optSplitIDs = splitIDs;
					n.opt_fea_id = i;
				}

			}else{
                HashMap<Integer, int[]> splitInformation = new HashMap<>();
				double[] d = new double[1];
				splitIDs = this.accuracyWithContinuousFeature(i,
					train_data.num_classes,n.data_list,splitInformation,d,n.num_accurate);

                if(splitIDs == null)continue;
				int totalAccuracy = DecisionTreeClass.calculateTotalAccuracy(splitInformation);
				// System.out.println("Total accuracy: " + totalAccuracy+
				// " before split accuracy: " + n.num_accurate);
				if(totalAccuracy-n.num_accurate > n.opt_improvement){
				    n.opt_improvement = totalAccuracy-n.num_accurate;
					n.opt_fea_type = 0;
					n.optSplitInformation = splitInformation;
					n.optSplitIDs = splitIDs;
					n.opt_fea_id = i;
					n.opt_fea_thd = d[0];
				}
			}

		}

	}

	public void BFS(DecisionTreeNode n){

    	LinkedList<DecisionTreeNode> q = new LinkedList<>();
		int level = -1;
        q.addLast(n);

		while(q.size() != 0){

        	DecisionTreeNode x = q.removeFirst();
			if(x.height != level){
				level++;
				System.out.println();
				System.out.print("level: " + level + "-");
				System.out.print("      "+ x.num_accurate +"/" + x.data_list.size() + "/" +
			    	x.opt_improvement+"/"+x.is_leaf + "/" + "#" + x.opt_fea_id);
			}else{
				System.out.print("      " + x.num_accurate +"/" + x.data_list.size() + "/" + x.opt_improvement + "/"+x.is_leaf
				+ "/" + "#" + x.opt_fea_id);
			}

			if(x.children!= null){
				for(DecisionTreeNode k: x.children){
					q.addLast(k);
				}
			}
		}
		System.out.println();
	}

	public ArrayList<Integer> predict(DataWrapperClass test_data){
		// for each data in the test_data
		//	   starting from the root,
		//	   at each node, go to the right child based on the splitting feature
		//	   continue until a leaf is reached
		//	   assign the label to the data based on the majority-class of the leaf node
		// return the list of predicted label
		boolean cat = true;
		if(test_data.num_cat_fea == 0)cat = false;
        // this.BFS(root);
		ArrayList<Integer> outPutLabel = new ArrayList<Integer>();

		for(int i = 0; i< test_data.num_data; i++){
            DecisionTreeNode cur = root;
            ArrayList<DecisionTreeNode> c = null;

			while(cur.is_leaf == false){
				c = cur.children;
                if(cat){
					ArrayList<ArrayList<Integer>> dataLine = test_data.categorical_features;

                    for(DecisionTreeNode x: c){
						if(x.featureValue == dataLine.get(i).get(cur.opt_fea_id)){
							cur = x;
							break;
						}
					}

					break;

				}else{

                    double threshold = cur.opt_fea_thd;
					ArrayList<ArrayList<Double>> dataLine = test_data.continuous_features;
					double fv = dataLine.get(i).get(cur.opt_fea_id);
					if(fv <= threshold){
						cur = c.get(0);
					}else{
						cur = c.get(1);
					}
				}
			}

			outPutLabel.add(cur.majority_class);
		}
		 return outPutLabel;
	}



	public static void main(String args[]){

		// DecisionTreeNode a = new DecisionTreeNode(null, 0,0);
		// DecisionTreeNode b = new DecisionTreeNode(null, 0,0);
		// a.opt_improvement = 10;
		// b.opt_improvement = 20;
		// PriorityQueue<DecisionTreeNode> x = new PriorityQueue<>();
		// x.add(a);
		// x.add(b);
		// System.out.println(x.poll().opt_improvement);

	}

}
