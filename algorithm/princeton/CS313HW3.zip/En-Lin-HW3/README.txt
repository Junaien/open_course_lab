I have solve all of them
My platform is MAC
