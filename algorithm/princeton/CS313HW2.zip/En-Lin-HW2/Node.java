public class Node{
    /**
     * private field
     */
    int index;
    Node next;
    int value;
    public Node(int index, int value, Node next){
        this.index = index;
        this.next = next;
        this.value = value;
    }




}
