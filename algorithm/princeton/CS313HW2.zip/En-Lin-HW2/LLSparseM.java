
public class LLSparseM implements SparseM {
    //private fields
    private RNode dummyHead;
    private int rLength;
    private int cLength;
    private int size;
    private int rSize;
     // number of all elements

    public LLSparseM(int nr, int nc){

        this.size = 0;
        this.dummyHead = new RNode(-1,null,null);
        this.rLength = nr;
        this.cLength = nc;
        this.rSize = 0;

    }

    public LLSparseM(LLSparseM other){
        if(other == null)throw new IllegalArgumentException(
        "argument for copy constructor can't be null");

        this.rLength = other.rLength;
        this.cLength = other.cLength;
        this.size = other.size;
        this.rSize = other.rSize;

        this.dummyHead = new RNode(-1,null,null);
        RNode p1 = this.dummyHead;
        RNode p2 = other.dummyHead.next;

        while(p2 != null){
            p1.next = new RNode(p2.index, new LLSparseVec(p2.vec), null);
            p1 = p1.next;
            p2 = p2.next;
        }
    }

	@Override
	public int nrows() {
		return rLength;
	}

	@Override
	public int ncols() {
		return cLength;
	}

	@Override
	public int numElements() {
        return size;
	}

    /**
     * get elements on the matrix
     * this is 0 based matrix
     * @param  int ridx          row index
     * @param  int cidx          columns index
     * @return     the value on that spot
     */
	@Override
	public int getElement(int ridx, int cidx) {

		checkOutOfBound(ridx, cidx);

        RNode cur = dummyHead;
        while(cur != null){
            if(ridx == cur.index){
                return cur.vec.getElement(cidx);
            }
            cur = cur.next;
        }
        return 0;
	}

    private void checkOutOfBound(int ridx, int cidx){
        if(ridx < 0 || ridx >= rLength
            || cidx < 0 || cidx >= cLength){
                throw new IllegalArgumentException(
                "illegal index for matrix");
        }
    }

    /**
     * remove a elements from the matrix
     * would do nothing if there is no such element
     * @param int ridx row index of matrix
     * @param int cidx column index of matrix
     */
	@Override
	public void clearElement(int ridx, int cidx) {
        checkOutOfBound(ridx, cidx);

        RNode curNode = dummyHead;
        while(curNode.next != null && curNode.next.index != ridx){
            curNode = curNode.next;
        }

        if(curNode.next == null){
            return;                   //do nothing if not found
        }else{
            int dif = curNode.next.vec.numElements();
            curNode.next.vec.clearElement(cidx);
            dif = curNode.next.vec.numElements() - dif;

            if(curNode.next.vec.numElements() == 0){
                curNode.next = curNode.next.next;
                rSize-- ;
            }
            size += dif;
        }
        return;

	}

    /**
     * set value of a specific element
     * not allow to set it to 0
     * @param int ridx row index
     * @param int cidx column index
     * @param int val  values to set
     */
	@Override
	public void setElement(int ridx, int cidx, int val) {

        if(val == 0){
            clearElement(ridx, cidx);
            return;
        }
        checkOutOfBound(ridx, cidx);

        RNode curNode = dummyHead;
        while(curNode.next != null){

            if(curNode.next.index == ridx){
                int dif = curNode.next.vec.numElements();
                curNode.next.vec.setElement(cidx,val);
                dif = curNode.next.vec.numElements() - dif;
                size += dif;
                return;
            }else if(curNode.next.index < ridx){
                curNode = curNode.next;
                continue;
            }else{
                RNode newNode = new RNode(
                    ridx,new LLSparseVec(cLength),curNode.next);
                newNode.vec.setElement(cidx,val);
                curNode.next = newNode;
                size++;
                rSize++;
                return;
            }

        }

        //the element must be the last one here
        RNode newNode = new RNode(
            ridx,new LLSparseVec(cLength),null);
        newNode.vec.setElement(cidx, val);
        curNode.next = newNode;
        rSize++;
        size++;
        return;

	}

	@Override
	public int[] getRowIndices() {

        
        RNode curNode = dummyHead;
        int[] indices = new int[rSize];
        curNode = curNode.next;
        int i = 0;
        while(curNode != null){
            indices[i] = curNode.index;
            i++;
            curNode = curNode.next;
        }
		return indices;
	}


	@Override
	public int[] getOneRowColIndices(int ridx) {

        if(ridx >= rLength || ridx < 0){
            throw new IllegalArgumentException(
                "illegal index for LLSparseVec");
        }

        RNode curNode = dummyHead.next;
        while(curNode != null){
            if(curNode.index == ridx){
                return curNode.vec.getAllIndices();
            }
            curNode = curNode.next;
        }
        return null;    //return null if no such row
	}

	@Override
	public int[] getOneRowValues(int ridx) {

        if(ridx >= rLength || ridx < 0){
            throw new IllegalArgumentException(
                "illegal index for LLSparseVec");
        }

        RNode curNode = dummyHead.next;
        while(curNode != null){
            if(curNode.index == ridx){
                return curNode.vec.getAllValues();
            }
            curNode = curNode.next;
        }
        return null;    //return null if no such row
	}

    private RNode binaryOp(
        int index, LLSparseVec v, String op, boolean reverse){

        if(v == null || v.numElements() == 0)return null;

        LLSparseVec temp = null;
        if(op == "*"){
            return null;
        }else if(op == "-"){

            if(reverse){
                temp = v.negate();
            }else{
                temp = new LLSparseVec(v);
            }

        }else if(op == "+"){
            temp = new LLSparseVec(v);
        }

        RNode r = new RNode(index,temp,null);
        size = size + temp.numElements();
        rSize ++;
        return r;

    }

    private RNode binaryOp(
        int index, LLSparseVec v1, LLSparseVec v2, String op){

        LLSparseVec temp = null;
        if(op == "*"){
            temp = (LLSparseVec)(v1.multiplication(v2));
        }else if(op == "-"){
            temp = (LLSparseVec)(v1.subtraction(v2));
        }else if(op == "+"){
            temp = (LLSparseVec)(v1.addition(v2));
        }

        if(temp.numElements() == 0 || temp == null){
            return null;
        }else{
            size += temp.numElements();
            rSize ++;
            return new RNode(index, temp, null);
        }
    }

    private SparseM operation(SparseM otherM, String op){
        if(otherM == null)throw new IllegalArgumentException("");

        LLSparseM other = (LLSparseM)otherM;
        if(other.rLength != this.rLength ||
           other.cLength != this.cLength)return null;

        LLSparseM mat = new LLSparseM(
            other.rLength, other.cLength);
        RNode cur = mat.dummyHead;

        RNode p2 = dummyHead.next;
        RNode finger = other.dummyHead.next;

        while(finger != null || p2 != null){

            if(p2 == null){
                if(op == "*"){
                    return mat;
                }else{
                    cur.next = mat.binaryOp(finger.index,finger.vec, op,true);
                    if(cur.next != null) cur= cur.next;
                    finger = finger.next;
                }
                continue;

            }else if(finger == null){

                if(op == "*"){
                    return mat;
                }else{
                    cur.next = mat.binaryOp(p2.index,p2.vec, op, false);
                    if(cur.next != null) cur = cur.next;
                    p2 = p2.next;
                }
                continue;
            }

            if(p2.index == finger.index){
                cur.next = mat.binaryOp(p2.index, p2.vec,finger.vec,op);
                if(cur.next != null)cur = cur.next;
                finger = finger.next;
                p2 = p2.next;

            }else if(p2.index < finger.index){
                cur.next = mat.binaryOp(p2.index, p2.vec,op, false);
                if(cur.next != null)cur = cur.next;
                p2 = p2.next;

            }else{
                cur.next = mat.binaryOp(finger.index,finger.vec,op, true);
                if(cur.next != null)cur = cur.next;
                finger = finger.next;
            }
        }
		return mat;

    }



	@Override
	public SparseM addition(SparseM otherM) {
        if(otherM == null)return new LLSparseM(this);
	    return operation(otherM, "+");
	}

	@Override
	public SparseM subtraction(SparseM otherM) {
        if(otherM == null)return new LLSparseM(this);
		return operation(otherM, "-");
	}

	@Override
	public SparseM multiplication(SparseM otherM) {
        if(otherM == null)return new LLSparseM(this.rLength,this.cLength);
		return operation(otherM,"*");
	}

}
