public class RNode{
    //private fields
    int index;
    LLSparseVec vec;
    RNode next;

    public RNode(int index, LLSparseVec vec, RNode next){
        this.index = index;
        this.vec = vec;
        this.next = next;
    }
}
