/*
 * this SparseM class would be 0 indexed
 */

public class LLSparseVec implements SparseVec {
    //private fields
    private int length;
    private Node dummyHead;
    private int size;

    public LLSparseVec(int len){
        if(len <= 0){
            throw new IllegalArgumentException(
            "length for LLSparseVec must be > 0");
        }
        this.length = len;
        this.size = 0;
        this.dummyHead = new Node(-1,-1,null);
    }
    //copy constructor
    public LLSparseVec(LLSparseVec v){
        if(v == null){
            throw new IllegalArgumentException(
            "copy a null object is not allowed");
        }
        this.length = v.length;
        this.size = v.size;
        this.dummyHead = new Node(-1,-1,null);
        Node p1 = this.dummyHead;
        Node p2 = v.dummyHead.next;

        while(p2 != null){
            p1.next = new Node(p2.index, p2.value, null);
            p1 = p1.next;
            p2 = p2.next;
        }
    }

    public LLSparseVec negate(){
        LLSparseVec vec = new LLSparseVec(this.length);
        vec.size = this.size;
        Node p = this.dummyHead.next;
        Node cur = vec.dummyHead;
        while(p != null){
            cur.next = new Node(p.index, -1*p.value, null);
            cur = cur.next;
            p = p.next;
        }
        return vec;
    }


	@Override
	public int getLength() {
		return length;
	}

	@Override
	public int numElements() {
	    return size;
	}
    private void checkOutOfBound(int idx){
        if(idx >= length || idx < 0){
            throw new IllegalArgumentException(
                "illegal index for LLSparseVec");
        }
    }
    /**
     * get element from this vector according to
     * index applied
     * @param  int idx           index of vector
     * @return                   return value at that index
     */
    @Override
	public int getElement(int idx) {
        checkOutOfBound(idx);

        Node curNode = this.dummyHead;
        while (curNode != null){
            if(curNode.index == idx){
                return curNode.value;
            }
            curNode = curNode.next;
        }
		return 0;
	}

    /**
     * set element in that index to 0
     * @param int idx index in LLSparseVec(0 based)
     */
	@Override
	public void clearElement(int idx) {
        checkOutOfBound(idx);

        Node curNode = dummyHead;
        //stop one node before the target node
        while(curNode.next != null && curNode.next.index != idx){
            curNode = curNode.next;
        }

        if(curNode.next == null){
            return;                   //do nothing if not found
        }else{
            curNode.next = curNode.next.next;
            size--;
        }
        return;
	}

    /**
     * insert element with indicated idx and val
     * change the value of current element if it already
     * exists
     *
     * @param int idx index
     * @param int val value of that elements
     */
	@Override
	public void setElement(int idx, int val) {
        checkOutOfBound(idx);
        if(val == 0){
            clearElement(idx);
            return;
        }

        Node curNode = dummyHead;
        while(curNode.next != null){

            if(curNode.next.index == idx){
                curNode.next.value = val;
                return;
            }else if(curNode.next.index < idx){
                curNode = curNode.next;
            }else{
                Node newNode = new Node(idx,val,curNode.next);
                curNode.next = newNode;
                size++;
                return;
            }
        }
        //the element must be the last one here
        Node newNode = new Node(idx,val,null);
        curNode.next = newNode;
        size++;
        return;
	}

    /**
     * return all index that is not zero in LLSparseVec
     * @return null if all elements' value are 0
     *         other wise return all index that has non-0
     *         value
     */
	@Override
	public int[] getAllIndices() {
        
        Node curNode = dummyHead.next;
        int[] indices = new int[size];
        int i = 0;
        while(curNode != null){
            indices[i] = curNode.index;
            i++;
            curNode = curNode.next;
        }
		return indices;
	}

	@Override
	public int[] getAllValues() {

        Node curNode = dummyHead;
        int[] values = new int[size];
        curNode = curNode.next;
        int i = 0;
        while(curNode != null){
            values[i] = curNode.value;
            i++;
            curNode = curNode.next;
        }
		return values;
	}


    private Node binaryOp(int index, int v1, int v2, String op){
        int temp = 0;
        if(op == "*"){
            temp = v1 * v2;
        }else if(op == "-"){
            temp = v1-v2;
        }else if(op == "+"){
            temp = v1+v2;
        }

        if(temp == 0){
            return null;
        }else{
            size++;
            return new Node(index, temp, null);
        }
    }

    private LLSparseVec operation(SparseVec otherV, String op){
        if (otherV == null)throw new IllegalArgumentException(
            "LLSparseVec addition has one null vector");
        if(otherV.getLength() != this.length)return null;

        LLSparseVec vec = new LLSparseVec(otherV.getLength());
        Node cur = vec.dummyHead;

        Node p2 = dummyHead.next;
        Node finger = ((LLSparseVec)otherV).dummyHead.next;

        while( finger != null || p2 != null){

            if(p2 == null){

                if(op == "*"){
                    return vec;
                }else{
                    cur.next = vec.binaryOp(finger.index, 0, finger.value, op);
                    if(cur.next != null) cur= cur.next;
                    finger = finger.next;
                }
                continue;

            }else if(finger == null){

                if(op == "*"){
                    return vec;
                }else{
                    cur.next = vec.binaryOp(p2.index,p2.value,0, op);
                    if(cur.next != null) cur = cur.next;
                    p2 = p2.next;
                }
                continue;
            }

            if(p2.index == finger.index){
                cur.next = vec.binaryOp(p2.index, p2.value,finger.value,op);
                if(cur.next != null)cur = cur.next;
                finger = finger.next;
                p2 = p2.next;

            }else if(p2.index < finger.index){
                cur.next = vec.binaryOp(p2.index, p2.value,0,op);
                if(cur.next != null)cur = cur.next;
                p2 = p2.next;

            }else{
                cur.next = vec.binaryOp(finger.index, 0,finger.value,op);
                if(cur.next != null)cur = cur.next;
                finger = finger.next;
            }
        }
		return vec;
    }

	@Override
	public SparseVec addition(SparseVec otherV) {
        if(otherV == null)return new LLSparseVec(this);
        return operation(otherV, "+");
	}

	@Override
	public SparseVec subtraction(SparseVec otherV) {
        if(otherV == null)return new LLSparseVec(this);
        return operation(otherV, "-");
	}

	@Override
	public SparseVec multiplication(SparseVec otherV) {
        if(otherV == null)return new LLSparseVec(this.length);
        return operation(otherV, "*");
	}

}
