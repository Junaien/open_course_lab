1) running on platform Mac
2) problem finished:
    Problem 1
    Problem 2
    Problem 3
    Problem 4