
import edu.princeton.cs.algs4.FordFulkerson;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.FlowNetwork;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.FlowEdge;
import java.util.ArrayList;

public class BaseballElimination{
    private int teamNum;
    private ArrayList<String> teams;
    private int[][] winsLossLeft;
    private int[][] IvsJ;
    // create a baseball division from given filename in format specified below
    public BaseballElimination(String filename){
        // System.out.println("Good here");

        In in = new In(filename);
        teamNum = Integer.parseInt(in.readLine());
        winsLossLeft = new int[teamNum][3];
        IvsJ = new int[teamNum][teamNum];
        teams = new ArrayList<>();
        // System.out.println("Good here");
            for(int i = 0; i < teamNum; i++){
                String[] temp = (in.readLine().trim()).split("\\s+");
                // System.out.println("Good here");
                // System.out.println(temp.length);

                this.teams.add(temp[0]);
                // System.out.println("Good here");

                winsLossLeft[i][0] = Integer.parseInt(temp[1]);
                winsLossLeft[i][1] = Integer.parseInt(temp[2]);
                winsLossLeft[i][2] = Integer.parseInt(temp[3]);
                // System.out.println("Good here");

                for(int j = 4; j < temp.length; j++){
                    IvsJ[i][j-4] = Integer.parseInt(temp[j]);
                }
            }

    }
    // number of teams
    public              int numberOfTeams(){
        return teamNum;
    }
    // all teams
    public Iterable<String> teams(){
        return this.teams;
    }
    // number of wins for given team
    private int getIndex(String name){
        for(int i = 0; i < teamNum; i++){
            if(teams.get(i).equals(name)){
                return i;
            }
        }
        return -1;
    }
    public              int wins(String team){
        int index = getIndex(team);
        if(index == -1)throw new IllegalArgumentException();
        return winsLossLeft[index][0];
    }
     // number of losses for given team
    public              int losses(String team){
        int index = getIndex(team);
        if(index == -1)throw new IllegalArgumentException();
        return winsLossLeft[index][1];
    }
    // number of remaining games for given team
    public              int remaining(String team){
        int index = getIndex(team);
        if(index == -1)throw new IllegalArgumentException();
        return winsLossLeft[index][2];
    }
    // number of remaining games between team1 and team2
    public              int against(String team1, String team2){
        int indexL = getIndex(team1);
        int indexR = getIndex(team2);
        if(indexL == -1)throw new IllegalArgumentException();
        if(indexR == -1)throw new IllegalArgumentException();

        if(indexL < indexR)
            return IvsJ[indexL][indexR];
        else
            return IvsJ[indexR][indexL];
    }
    private int trivialElimination(int v){
        int win = winsLossLeft[v][0] + winsLossLeft[v][2];
        for(int i = 0 ;i <teamNum; i++){
            if(i != v && winsLossLeft[i][0] > win){
                return i;
            }
        }
        return -1;
    }
    private FlowNetwork buildFlowNetwork(int v){
        int size = teamNum*(teamNum-1)/2 +1;
        size -= teamNum;
        FlowNetwork f  = new FlowNetwork(size + 2 + teamNum);
        // System.out.println("size: " + size);
        // System.out.println("teamNum: " + teamNum);

        //set all edges from node to t
        for(int i = 0; i < teamNum; i++){
            if(i != v){
                double capacity = winsLossLeft[v][2]
                    + winsLossLeft[v][0] -
                    winsLossLeft[i][0];
                FlowEdge fEdge = new FlowEdge(i, teamNum+1, capacity);
                f.addEdge(fEdge);
            }
        }

        //addEdge from s to game and agame to nodes
        int target = teamNum+2;
        for(int i = 0; i < teamNum; i++){
            for(int j = i+1; j < teamNum; j++){
                if(i != v && j != v){
                    FlowEdge sToGame = new FlowEdge(teamNum,target, IvsJ[i][j]);
                    FlowEdge gameToNode1 = new FlowEdge(target,i,Double.POSITIVE_INFINITY);
                    FlowEdge gameToNode2 = new FlowEdge(target,j,Double.POSITIVE_INFINITY);
                    f.addEdge(sToGame);
                    f.addEdge(gameToNode1);
                    f.addEdge(gameToNode2);
                    target++;
                }
            }
        }
        return f;
    }
    private int remainGameWithout(int v){
        int total = 0;
        for(int i = 0; i < teamNum; i++ ){
            for(int j = i + 1; j < teamNum; j++){
                if(i != v && j!= v)
                    total += IvsJ[i][j];
            }
        }
        return total;
    }
    // is given team eliminated?
    public          boolean isEliminated(String team){
        int index = getIndex(team);
        if(index == -1)throw new IllegalArgumentException();

        if(trivialElimination(index) != -1)return true;
        FlowNetwork f = buildFlowNetwork(index);
        FordFulkerson ford = new FordFulkerson(f, teamNum, teamNum+1);
        return ford.value() != remainGameWithout(index);

    }
    // subset R of teams that eliminates iven team; null if not eliminated
    public Iterable<String> certificateOfElimination(String team){
        int index = getIndex(team);
        if(index == -1)throw new IllegalArgumentException();
        ArrayList<String> s = new ArrayList<>();
        int e = trivialElimination(index);
        if(e != -1){
            s.add(teams.get(e));
            return s;
        }
        FlowNetwork f = buildFlowNetwork(index);
        FordFulkerson ford = new FordFulkerson(f, teamNum, teamNum+1);
        //loop through vertice from behind

        for(int i = 0; i < teamNum; i++){
            if( i == index || !ford.inCut(i))continue;
            else{
                s.add(teams.get(i));
            }
        }
        return s.size() == 0? null : s;
    }
    //main
    public static void main(String[] args){
        BaseballElimination division = new BaseballElimination(args[0]);
        // System.out.println(args[0]);
        for( String team: division.teams()){
            if(division.isEliminated(team)){
                StdOut.print(team + " is eliminated by the subset R= { ");
                for(String t : division.certificateOfElimination(team)){
                    StdOut.print(t + " ");
                }
                StdOut.println("}");
            }else{
                StdOut.println(team + " is not eliminated");
            }
        }
    }
}
