import java.util.ArrayList;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;
import java.util.HashSet;
public class BoggleSolver{
    private static final int R = 26;
    private Node root;
    private int rowSize;
    private int colSize;
    private static class Node{
        public boolean isString;
        public Node[] children = new Node[R];
    }
    // Initializes the data structure using the given array of strings as the dictionary.
    // (You can assume each word in the dictionary contains only the uppercase letters A through Z.)
    public BoggleSolver(String[] dictionary){
        if (dictionary == null) throw new IllegalArgumentException();
        root = new Node();
        buildTrie(dictionary);
        // System.out.println("Ready for dict: ");
        // printDict();
    }

    private void buildTrie(String[] dictionary){
        for (int i = 0; i < dictionary.length; i++){
            // System.out.println(dictionary[i]);
            if(dictionary[i].length() <= 2)continue;
            root = put(root, dictionary[i], 0);
        }
    }

    private boolean contains(String key){
        Node x = get(root, key, 0);
        if(x == null)return false;
        return x.isString;
    }

    private Node get(Node x, String key, int d){
        if(x == null)return null;
        if(d == key.length())return x;
        char c = key.charAt(d);
        return get(x.children[mappingChar(c)], key, d+1);

    }

    private Node put(Node x, String key, int d){

        if(x == null) x = new Node();
        if(d == key.length()){
            x.isString = true;
        }else {
            int index = mappingChar(key.charAt(d));
            x.children[index] = put(x.children[index], key, d+1);
        }
        return x;
    }
    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board){
        if(board == null) throw new IllegalArgumentException();
        rowSize = board.rows();
        colSize = board.cols();

        HashSet<String> words = new HashSet<>();
        for(int i = 0; i < rowSize; i++){
            for(int j = 0; j < colSize; j++){
                char k = board.getLetter(i,j);
                boolean[][] mark = new boolean [rowSize][colSize];
                if(k == 'Q'){
                    backTrackQ(root, words, board, i, j, mark, new StringBuilder(""));
                }else backTrack(root, words, board, i, j, mark, new StringBuilder(""));
            }
        }
        return words;
    }

    private void backTrackQ(Node x, HashSet<String> words, BoggleBoard board,
        int row, int col, boolean[][] mark, StringBuilder s){
            mark[row][col] = true;
            x = x.children[mappingChar('Q')];
            s.append('Q');
            if(x == null){
                s.deleteCharAt(s.length()-1);
                mark[row][col] = false;
                return;
            }
            x = x.children[mappingChar('U')];
            if(x == null){
                s.deleteCharAt(s.length()-1);
                mark[row][col] = false;
                return;
            }
            s.append('U');
            if(x.isString)words.add(s.toString());
            int target = row * colSize + col;
            for(int i:adj(target)){
                int r = toRow(i);
                int c = toCol(i);
                if(mark[r][c])continue;
                char k = board.getLetter(r,c);
                if(k == 'Q')backTrackQ(x, words, board, r, c, mark, s);
                else{
                    backTrack(x,words, board, r, c, mark, s);
                }
            }

            s.deleteCharAt(s.length()-1);
            s.deleteCharAt(s.length()-1);
            // System.out.println("Pop: " + ch)
            mark[row][col] = false;

        }

    private void backTrack(Node x, HashSet<String> words, BoggleBoard board,
        int row, int col, boolean[][] mark, StringBuilder s){

        mark[row][col] = true;
        char ch = board.getLetter(row,col);
        s.append(ch);
        // if(ch == 'Q')s.append('U');
        // System.out.println("Append: " + ch);
        int index = mappingChar(ch);
        int target = row * colSize + col;

        if(x.children[index] == null){
            // if(ch == 'Q')s.deleteCharAt(s.length()-1);
            s.deleteCharAt(s.length()-1);
            // System.out.println("Pop: " + ch);
            mark[row][col] = false;
            return;
        }

        if(x.children[index].isString == true){
            words.add(s.toString());
            // System.out.println("Add word: " + s.toString());
        }
        for(int i : adj(target)){
            int r = toRow(i);
            int c = toCol(i);
            if(mark[r][c])continue;
            char k = board.getLetter(r,c);
            if(k == 'Q')backTrackQ(x.children[index],words, board, r, c, mark, s);
            else{
                backTrack(x.children[index],words, board, r, c, mark, s);
            }
        }
        s.deleteCharAt(s.length()-1);
        // System.out.println("Pop: " + ch)
        mark[row][col] = false;
    }

    private Iterable<Integer> adj(int index){

        ArrayList<Integer> l = new ArrayList<>();
        int r = toRow(index);
        int c = toCol(index);

        if(inrange(r-1,c)){
            l.add((r-1)*colSize + c);
        }
        if(inrange(r+1,c)){
            l.add((r+1)*colSize + c);
        }
        if(inrange(r,c-1)){
            l.add(r*colSize + c-1);
        }
        if(inrange(r,c+1)){
            l.add(r*colSize + c+1);
        }
        if(inrange(r-1,c-1)){
            l.add((r-1)*colSize + c-1);
        }
        if(inrange(r-1,c+1)){
            l.add((r-1)*colSize + c+1);
        }
        if(inrange(r+1,c-1)){
            l.add((r+1)*colSize + c-1);
        }
        if(inrange(r+1,c+1)){
            l.add((r+1)*colSize + c+1);
        }

        return l;
    }

    private boolean inrange(int r, int c){
        if(r < 0 || r >= rowSize || c < 0 || c >= colSize)return false;
        return true;
    }

    private int toRow(int k){
        return  k / colSize;
    }

    private int toCol(int k){
        return k % colSize;
    }

    private int mappingChar(char c){
        return (c-65);
    }
    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word){
        if(word == null) throw new IllegalArgumentException();
        int length = word.length();
        if (length <= 2 || !contains(word))return 0;
        else if(length <= 4)return 1;
        else if(length == 5)return 2;
        else if(length == 6)return 3;
        else if(length == 7)return 5;
        else return 11;
    }

    private void printDict(){
         keyWithPrefix("");
    }

    private void keyWithPrefix(String prefix){
        collect(root, new StringBuilder(prefix));
    }

    private void collect(Node x, StringBuilder prefix){
        if(x == null) return;
        if(x.isString)System.out.println(prefix.toString());
        for(char c = 0; c < R; c++) {
            prefix.append((char)(c+65));
            collect(x.children[c],prefix);
            prefix.deleteCharAt(prefix.length() - 1);
        }
    }

    public static void main(String[] args) {
        In in = new In(args[0]);
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(args[1]);
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
    }
}
