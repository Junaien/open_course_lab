
import edu.princeton.cs.algs4.Picture;
import java.awt.Color;
import java.util.ArrayList;

public class SeamCarver {

   private int[][] pixelArray;
   private double[][] energy;
   private int height;
   private int width;
   private boolean Tmode = false;
   public SeamCarver(Picture picture){
       this.height = picture.height();
       this.width = picture.width();
       System.out.println("  ");
       //initialize color Array
       pixelArray = new int[width][height];
       energy = new double[width][height];
       for(int i = 0; i < width; i++){
           for(int j = 0 ; j< height; j++){
               pixelArray[i][j] = picture.get(i,j).getRGB();
           }
       }

       for(int i = 0; i < width; i++){
           for(int j = 0 ; j< height; j++){
               updateEnergy(i,j);
           }
       }

   }

   public Picture picture(){
       if(Tmode){
           transposePic();
           Tmode = false;
       }
       Picture p = new Picture(width, height);
       for(int i = 0; i < width; i++)
           for(int j = 0; j < height; j++){
               int x = pixelArray[i][j];
               int r = red(x);
               int g = green(x);
               int b = blue(x);
               p.set(i,j,new Color(r,g,b));
           }

      return p;
   }

   public int width(){
       if(Tmode)return height;
       else return width;
   }

   public int height(){
       if(!Tmode)return height;
       else return width;
   }

   private boolean inRange(int x, int y){
        if(x < 0 || x >= width || y < 0 || y >= height)return false;
        else return true;
   }

   public double energy(int x, int y) {
       // System.out.println("col:"+ width + "row:" + height);
       // System.out.println("Arraycol: "+pixelArray.size() + "Arrayrow: " + pixelArray.get(0).size() );
       if(Tmode){
           int temp = x;
           x = y;
           y = temp;
       }

       if(!inRange(x,y))throw new IllegalArgumentException();
       return energy[x][y];
   }

   public int[] findHorizontalSeam(){
       if(Tmode){
           Tmode = false;
           // updated = false;
           return findHorizontalSeam(true);
       }else{
           return findHorizontalSeam(false);
       }
   }

   public int [] findVerticalSeam(){
       if(!Tmode){
           Tmode = true;
           // updated = false;
           return findHorizontalSeam(true);
       }else{
           return findHorizontalSeam(false);
       }
   }

   private int[] findHorizontalSeam(boolean transpose){
       if(transpose == true)transposePic();
       // Pixel top = new Pixel(-1,-1, null, 0);
       // Pixel bottom = new Pixel(-2,-2, null, 0);
       double [][] distTo = new double[width][height];
       for(int i = 0 ; i < height ; i ++){
           distTo[0][i] = 1000;
       }

       int [][] edgeTo = new int[width][height] ;
       relaxationProcess(distTo,edgeTo);

       int opt_index = 0;
       double opt_dis = distTo[width-1][0];
       for(int i = 1 ; i < height; i++){
           if(distTo[width-1][i] < opt_dis){
               opt_dis = distTo[width-1][i];
               opt_index = i;
           }
       }

       int [] opt_path = new int[width];
       int temp = opt_index;
       for(int i = width-1; i >= 0; i--){
           opt_path[i] = temp;
           // System.out.println(temp.col + "/" + width);
           // System.out.println("height = " + height);
           if(i!= 0)temp = edgeTo[i][temp];
       }

       return opt_path;
   }

   private void transposePic(){
       int[][] pixelArrayT = new int[height][width];
       double[][] energyT = new double[height][width];

       for(int i = 0; i < height; i++){
           for(int j = 0; j < width; j++){
               pixelArrayT[i][j] = pixelArray[j][i];
               energyT[i][j] = energy[j][i];
           }
       }
       this.pixelArray = pixelArrayT;
       this.energy = energyT;
       int temp = height;
       this.height = width;
       this.width = temp;
       // updated = false;
   }

   public void removeHorizontalSeam(int[] seam){
       if(Tmode){
           Tmode = false;
           removeHorizontalSeam(seam,true);
       }else{
           removeHorizontalSeam(seam,false);
       }
       // updated = false;
   }

   public void removeVerticalSeam(int[] seam){
       if(seam == null)throw new IllegalArgumentException();

       if(!Tmode){
           removeHorizontalSeam(seam, true);
           Tmode = true;
       }else{
           removeHorizontalSeam(seam,false);
       }
   }

   private void removeHorizontalSeam(int[] seam, boolean transpose){

       if(transpose)transposePic();
       int[][] p = new int[width][height-1];
       double[][] e = new double[width][height-1];
       if (seam == null || seam.length != width)
            throw new IllegalArgumentException();
       if(height <= 1)throw new IllegalArgumentException();

       for(int i = 0; i < width; i++){
           if(i+1 < width && Math.abs(seam[i] - seam[i+1])>1)
            throw new IllegalArgumentException();
           if(seam[i] < 0 || seam[i] >= height)
            throw new IllegalArgumentException();

           System.arraycopy(pixelArray[i],0,p[i],0,seam[i]);
           System.arraycopy(pixelArray[i],seam[i]+1,p[i],seam[i], height-seam[i]-1);
           System.arraycopy(energy[i],0,e[i],0,seam[i]);
           System.arraycopy(energy[i],seam[i]+1,e[i],seam[i], height-seam[i]-1);
       }
       this.pixelArray = p;
       this.energy = e;
       height--;
       for(int i = 0; i < width; i++){
           if(inRange(i,seam[i]))updateEnergy(i,seam[i]);
           if(inRange(i,seam[i]-1))updateEnergy(i,seam[i]-1);
       }
       // updated = false;
   }

   private void relaxationProcess(double[][] distTo, int [][] edgeTo){
       for(int i = 0; i< width; i++){
           for(int j = 0; j < height; j++){
               relax(i,j,distTo, edgeTo);
           }
       }
   }

   private void relax(int x, int y,double[][] distTo, int [][] edgeTo){
       // int upY = y-1;
       int upY = y -1;
       int downY = y+1;
       int rightX = x +1;

       if(inRange(rightX,y)){
           if(distTo[rightX][y] == 0 ||
            distTo[rightX][y] > distTo[x][y] + energy[rightX][y]){

               distTo[rightX][y] = distTo[x][y] + energy[rightX][y];
               edgeTo[rightX][y] = y;
           }
       }
       if(inRange(rightX,upY)){
           if(distTo[rightX][upY] == 0 ||
            distTo[rightX][upY] > distTo[x][y] + energy[rightX][upY]){

               distTo[rightX][upY] = distTo[x][y] + energy[rightX][upY];
               edgeTo[rightX][upY] = y;
           }
       }

       if(inRange(rightX,downY)){
           if(distTo[rightX][downY] == 0 ||
            distTo[rightX][downY] > distTo[x][y] + energy[rightX][downY]){

               distTo[rightX][downY] = distTo[x][y] + energy[rightX][downY];
               edgeTo[rightX][downY] = y;
           }
       }




   }

   private void updateEnergy(int x , int y){
       if(!inRange(x,y))throw new IllegalArgumentException();

       double energy  = calculateEnergy(x,y);
       this.energy[x][y] = energy;
   }

   private double calculateEnergy(int x, int y){
       if(!inRange(x,y))throw new IllegalArgumentException();

       if(x == 0 || x == width-1 || y == 0 || y == height-1){
           return 1000;
       }

       int top = pixelArray[x][y-1];
       int bottom = pixelArray[x][y+1];
       int left = pixelArray[x-1][y];
       int right = pixelArray[x+1][y];
       double Rx2 = Math.pow(red(left)- red(right),2)+
           Math.pow(blue(left) - blue(right),2)+
           Math.pow(green(left) - green(right),2);
       double Ry2 = Math.pow(red(top) - red(bottom),2)+
           Math.pow(blue(top) - blue(bottom),2)+
           Math.pow(green(top) - green(bottom),2);

       return Math.sqrt(Rx2 + Ry2);
   }
   private int red(int rgb){
       return (rgb >> 16)  & 0xFF;
   }
   private int green(int rgb){
       return (rgb >> 8) & 0xFF;
   }
   private int blue(int rgb){
       return (rgb >> 0) & 0xFF;
   }
}
