package edu.qc.seclass.tipcalculator;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class TipCalculatorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip_calculator);
    }

    public void ComputeTip(View view){
        Context context = getApplicationContext();
        TextView checkTextView = findViewById(R.id.checkAmountValue);
        TextView splitTextView = findViewById(R.id.partySizeValue);
        if(checkTextView.getText().toString().equals("") || splitTextView.getText().toString().equals("")){
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(context, "Check amout and party size can't be blank", duration);
            toast.setGravity(Gravity.TOP|Gravity.LEFT, 0, 0);
            toast.show();
        }else {
            double checkAmout = Double.valueOf(checkTextView.getText().toString());
            int split = Integer.valueOf(splitTextView.getText().toString());
            int total15 = (int) Math.ceil((checkAmout * 1.15) / split);
            int total20 = (int) Math.ceil((checkAmout * 1.20) / split);
            int total25 = (int) Math.ceil((checkAmout * 1.25) / split);
            int tip15 = (int) Math.ceil((checkAmout * 0.15) / split);
            int tip20 = (int) Math.ceil((checkAmout * 0.20) / split);
            int tip25 = (int) Math.ceil((checkAmout * 0.25) / split);
            TextView fifteenTip = findViewById(R.id.fifteenPercentTipValue);
            fifteenTip.setText(Integer.toString(tip15));
            TextView twentyTip = findViewById(R.id.twentyPercentTipValue);
            twentyTip.setText(Integer.toString(tip20));
            TextView twentyfiveTip = findViewById(R.id.twentyfivePercentTipValue);
            twentyfiveTip.setText(Integer.toString(tip25));

            TextView fifteenValue = findViewById(R.id.fifteenPercentTotalValue);
            fifteenValue.setText(Integer.toString(total15));
            TextView twentyValue = findViewById(R.id.twentyPercentTotalValue);
            twentyValue.setText(Integer.toString(total20));
            TextView twentyfiveValue = findViewById(R.id.twentyfivePercentTotalValue);
            twentyfiveValue.setText(Integer.toString(total25));

        }



    }

}
