purpose:
    this is a useful tip calculator, which helps you split
    your bill with your friends.

usage:
    enter the total bill amount into the line with Check amount tag.
    enter the total split size  into the line with Party Size   tag.
    press COMPUTE TIP.
    the tip value and total paid value for each person will be displayed.
