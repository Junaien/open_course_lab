package edu.qc.seclass;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class MyCustomStringTest {

    private MyCustomStringInterface mycustomstring;

    @Before
    public void setUp() {
        mycustomstring = new MyCustomString();
    }

    @After
    public void tearDown() {
        mycustomstring = null;
    }

    /**
     * [internal string has more than 1 numbers]
     */
    @Test
    public void testCountNumbers1() {
        mycustomstring.setString("I'd b3tt3r put s0me d161ts in this 5tr1n6, right?");
        assertEquals(7, mycustomstring.countNumbers());
    }

    /**
     * [internal string has 0 number]
     */
    @Test
    public void testCountNumbers2() {
        mycustomstring.setString("I'd bttr put sme dts in this trn, right?");
        assertEquals(0, mycustomstring.countNumbers());

    }

    /**
     * [internal string is empty]
     */
    @Test
    public void testCountNumbers3() {
        mycustomstring.setString("");
        assertEquals(0, mycustomstring.countNumbers());
    }

    /**
     * [internal string is null,this method should throw NullPointer Exception]
     */
    @Test(expected = NullPointerException.class)
    public void testCountNumbers4() {
    	mycustomstring.setString(null);
        assertEquals(0, mycustomstring.countNumbers());

    }

    /**
     * [internal string is a number]
     */
    @Test
    public void testCountNumbers5() {
        mycustomstring.setString("1");
        assertEquals(1, mycustomstring.countNumbers());

    }

    /**
     * [internal string is a long sequence of digits ends with a non-digit]
     */
    @Test
    public void testCountNumbers6() {
    	mycustomstring.setString("000666678879x");
        assertEquals(1, mycustomstring.countNumbers());
    }

    /**
     * [internal string is more than 3 times longer than the input parameter n]
     * [extract character from left to right]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd1() {
        mycustomstring.setString("I'd b3tt3r put s0me d161ts in this 5tr1n6, right?");
        assertEquals("d33p md1  i51,it", mycustomstring.getEveryNthCharacterFromBeginningOrEnd(3, false));
    }

    /**
     * [internal string is more than 3 times longer than the input parameter n]
     * [extract character from right to left]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd2() {
        mycustomstring.setString("I'd b3tt3r put s0me d161ts in this 5tr1n6, right?");
        assertEquals("'bt t0 6snh r6rh", mycustomstring.getEveryNthCharacterFromBeginningOrEnd(3, true));
    }

    /**
     * [internal string is null, method should throw NullPointerException]
     */
    @Test(expected = NullPointerException.class)
    public void testGetEveryNthCharacterFromBeginningOrEnd3() {
        mycustomstring.setString(null);
    	mycustomstring.getEveryNthCharacterFromBeginningOrEnd(1, true);

    }

    /**
     * [input parameter n is equal to 0, method should throw IllegalArgument exception]
     */
    @Test(expected = IllegalArgumentException.class)
    public void testGetEveryNthCharacterFromBeginningOrEnd4() {
    	mycustomstring.setString("nothing");
    	mycustomstring.getEveryNthCharacterFromBeginningOrEnd(0, true);
    }

    /**
     * [input parameter n is larger than the length of internal string, method should return empty string]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd5() {
    	mycustomstring.setString("n");
        assertEquals("", mycustomstring.getEveryNthCharacterFromBeginningOrEnd(3, true));
    	mycustomstring.setString("");
    	assertEquals("",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(5, false));
    }

    /**
     * [length of internal string is exactly twice the input parameter n]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd6() {
    	mycustomstring.setString("12345671234567");
        assertEquals("77", mycustomstring.getEveryNthCharacterFromBeginningOrEnd(7, false));
        assertEquals("11", mycustomstring.getEveryNthCharacterFromBeginningOrEnd(7, true));
    }

    /**
     * [input parameter n is less than 0, method should throw IllegalArgument exception]
     */
    @Test(expected = IllegalArgumentException.class)
    public void testGetEveryNthCharacterFromBeginningOrEnd7() {
    	mycustomstring.setString("hey");
    	mycustomstring.getEveryNthCharacterFromBeginningOrEnd(-1, true);
    }

    /**
     * [internal string's length is exactly the same as input parameter n]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd8() {
    	mycustomstring.setString("linennanhai");
    	assertEquals("i",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(11, false));
    	assertEquals("l",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(11, true));
    }

    /**
     * [internal string's length is between 1 and 2 times the input parameter n]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd9() {
    	mycustomstring.setString("linen");
    	assertEquals("n",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(3, true));
    	assertEquals("n",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(3, false));

    }

    /**
     * [internal string's length is between 2 and 3 times the input parameter n]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd10() {
    	mycustomstring.setString("linennanhai");
    	assertEquals("na",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(5, false));
    	assertEquals("ia",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(5, true));
    }

    /**
     * [internal string is empty]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd11() {
    	mycustomstring.setString("");
    	assertEquals("",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(4, true));
    	assertEquals("",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(4, false));
    }

    /**
     * [input parameter n is 1]
     * [extract character from left to right]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd12() {
    	mycustomstring.setString("I am very very hungry");
    	assertEquals("I am very very hungry",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(1, false));

    }

    /**
     * [input parameter n is 1]
     * [extract character from right to left]
     */
    @Test
    public void testGetEveryNthCharacterFromBeginningOrEnd13() {
    	mycustomstring.setString("12345");
    	assertEquals("12345",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(1, false));

    }

    /**
     * [method should throw IllegalArgumentException when input parameter is negative and internal string is empty]
     */
    @Test(expected = IllegalArgumentException.class)
    public void testGetEveryNthCharacterFromBeginningOrEnd14() {
    	mycustomstring.setString("");
    	assertEquals("",mycustomstring.getEveryNthCharacterFromBeginningOrEnd(-6, false));
    }

    /**
     * [startPosition and endPosition is legal and doesn't cover the whole string]
     */
    @Test
    public void testConvertDigitsToNamesInSubstring1() {
        mycustomstring.setString("I'd b3tt3r put s0me d161ts in this 5tr1n6, right?");
        mycustomstring.convertDigitsToNamesInSubstring(17, 23);
        assertEquals("I'd b3tt3r put sZerome dOneSix1ts in this 5tr1n6, right?", mycustomstring.getString());
    }

    /**
     * [method should throw IllegalArgumentException when startPosition > endPosition]
     */
    @Test(expected=IllegalArgumentException.class)
    public void testConvertDigitsToNamesInSubstring2() {
        mycustomstring.setString("I'd b3tt3r put s0me d161ts in this 5tr1n6, right?");
        mycustomstring.convertDigitsToNamesInSubstring(23,17);
    }

    /**
     * [method should throw MyIndexOutOfBoundsException when startPosition <= endPosition, but the interval is out of bound]
     */
    @Test(expected=MyIndexOutOfBoundsException.class)
    public void testConvertDigitsToNamesInSubstring3() {
    	mycustomstring.setString("I'd b3tt3r");
        mycustomstring.convertDigitsToNamesInSubstring(9, 11);
    }

    /**
     * [method should throw NullPointerException when internal string is null]
     */
    @Test(expected = NullPointerException.class)
    public void testConvertDigitsToNamesInSubstring4() {
    	mycustomstring.setString(null);
        mycustomstring.convertDigitsToNamesInSubstring(2, 4);
    }

    /**
     * [method should only convert digits to names in the interval from startPosition to endPosition]
     */
    @Test
    public void testConvertDigitsToNamesInSubstring5() {
    	mycustomstring.setString("00Isdsa13");
        mycustomstring.convertDigitsToNamesInSubstring(2, 3);
        assertEquals("0ZeroIsdsa13", mycustomstring.getString());

    }
    /**
     * [method should throw MyIndexOutOfBoundsException when internal string is empty, because it's definitely out of bound]
     */
    @Test(expected=MyIndexOutOfBoundsException.class)
    public void testConvertDigitsToNamesInSubstring6() {
    	mycustomstring.setString("");
        mycustomstring.convertDigitsToNamesInSubstring(1, 1);

    }

    /**
     * [internal string only contains one single digit]
     */
    @Test
    public void testConvertDigitsToNamesInSubstring7() {
    	mycustomstring.setString("1");
        mycustomstring.convertDigitsToNamesInSubstring(1, 1);
        assertEquals("One", mycustomstring.getString());
        mycustomstring.setString("2");
        mycustomstring.convertDigitsToNamesInSubstring(1, 1);
        assertEquals("Two", mycustomstring.getString());

    }

    /**
     * [startPosition and endPosition is legal and covers the whole string]
     */
    @Test
    public void testConvertDigitsToNamesInSubstring8() {
    	mycustomstring.setString("1xxxx0");
        mycustomstring.convertDigitsToNamesInSubstring(1, 6);
        assertEquals("OnexxxxZero", mycustomstring.getString());

    }

}
