package edu.qc.seclass;

public class MyCustomString implements MyCustomStringInterface {
    private String internalData;
    private static String[] digitToCharTable = new String[] {"Zero","One","Two","Three",
    		                                      "Four","Five","Six","Seven",
    		                                      "Eight","Nine"};
	public MyCustomString() {
	}

	@Override
	public String getString() {
		return internalData;
	}

	@Override
	public void setString(String string) {
		internalData = string;
	}

	@Override
	public int countNumbers() {
		if(internalData == null)throw new NullPointerException("internal data missing");
		else if(internalData == "")return 0;
		int rt = 0, n = internalData.length();
		boolean sameDigit = false;
		for(int i = 0 ; i < n;i++) {
			if(Character.isDigit(internalData.charAt(i))&& !sameDigit) {
				rt++;
				sameDigit = true;
			
			}else if (Character.isDigit(internalData.charAt(i)) && sameDigit){
				
			}else {
				sameDigit = false;
			}
		}
		return rt;
	}

	@Override
	public String getEveryNthCharacterFromBeginningOrEnd(int n, boolean startFromEnd) {
		if(n <= 0)throw new IllegalArgumentException("n can't be less or equal to 0");
		if(internalData == null)throw new NullPointerException("internal data missing");
		int size = internalData.length();
		int startPosition = startFromEnd? size-1 : 0;
		int step = startFromEnd? -1:1;
		String rt = "";
		for(int i = startPosition; i>=0 && i< size;i+=step) 
		{
			if((Math.abs(i - startPosition) +1) % n == 0 ) 
			{
				if(startFromEnd) rt = internalData.substring(i,i+1) + rt;
				else rt = rt + internalData.substring(i,i+1);
			}
		}
		
		return rt;
	}

	@Override
	public void convertDigitsToNamesInSubstring(int startPosition, int endPosition) {
		if(internalData == null)throw new NullPointerException("internal data missing");
		else if(startPosition > endPosition)throw new IllegalArgumentException("illegal start and end position");
		else if(startPosition < 1 || endPosition > internalData.length())throw new MyIndexOutOfBoundsException("index out of bound");
		

		String piece = internalData.substring(startPosition-1,endPosition);
		for(int i = 0;i < 10;i++) {
			piece = piece.replaceAll(String.valueOf(i), digitToCharTable[i]);
		}
		internalData = internalData.substring(0,startPosition-1) + piece + internalData.substring(endPosition);
		return;
	}

	public static void main(String[] args) {
		MyCustomString s = new MyCustomString();
		s.setString("abcabcabc");
		System.out.println(s.getEveryNthCharacterFromBeginningOrEnd(1, false));
		s.setString("12sdsa4100");
		s.convertDigitsToNamesInSubstring(1, 7);
	 	System.out.println(s.getString());
	}

}
