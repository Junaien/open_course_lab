package edu.qc.seclass;

public class BuggyClass{
  public int buggyMethod1(int k){
    int dangerousDivisor = 0;
    if(k == 1){
      dangerousDivisor = 1;
      System.out.println("the divisor is " + dangerousDivisor);
    }else if(k == 2){
      dangerousDivisor = 2;
      System.out.println("the divisor is " + dangerousDivisor);
    }
    return 10 / dangerousDivisor;
  }
  
  public int buggyMethod2(int k) {
	  int dangerousDivisor = 0;
	  if(k == 1) {
		  dangerousDivisor = 1;
	  }
	  return 10 / dangerousDivisor;
  }
  
  
  public int buggyMethod3(int k) {
	  if(k == 1)return 10 /k;
	  else return 4/k;
  }
  
  public void buggyMethod4() {
	  /*
	   * According to test criteria subsumption rules,
	   * if one test suit satisfies 100% branch coverage
	   * it must also satisfies 100% statement coverage
	   * since every test suit that achieves 100% statement coverage reveal,
	   * the requirement for this method reaches a contradiction.
	   */
  }
  
  public void buggyMethod5(int i) {
	  /*
	   * since the test suit has 100% statement coverage
	   * some test case must execute line 4
	   * if some test case executes line 4, it must reveal the error
	   */
  }
  
}
