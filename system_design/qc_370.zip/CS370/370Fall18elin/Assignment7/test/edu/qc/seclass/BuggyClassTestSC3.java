package edu.qc.seclass;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BuggyClassTestSC3 {
	BuggyClass myBuggyInstance;
	@Before
	public void setUp() throws Exception {
		myBuggyInstance = new BuggyClass();

	}

	@After
	public void tearDown() throws Exception {
		myBuggyInstance = null;
	}

	@Test
	public void testKEquals0() {
		int rt = myBuggyInstance.buggyMethod3(0);
		assertEquals(rt,-1);
	}

}
