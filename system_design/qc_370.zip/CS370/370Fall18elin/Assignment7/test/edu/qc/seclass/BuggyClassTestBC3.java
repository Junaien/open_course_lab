package edu.qc.seclass;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BuggyClassTestBC3 {
	BuggyClass myBuggyInstance;
	@Before
	public void setUp() throws Exception {
		myBuggyInstance = new BuggyClass();

	}

	@After
	public void tearDown() throws Exception {
		myBuggyInstance = null;
	}

	@Test
	public void testKEqual1() {
		int rt = myBuggyInstance.buggyMethod3(1);
		assertEquals(rt,10);
	}

	@Test
	public void testKNotEqual1() {
		int rt = myBuggyInstance.buggyMethod3(2);
		assertEquals(rt,2);
	}

}
