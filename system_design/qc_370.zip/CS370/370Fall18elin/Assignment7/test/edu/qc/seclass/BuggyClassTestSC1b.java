package edu.qc.seclass;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
public class BuggyClassTestSC1b{
  private BuggyClass myBuggyInstance;

  @Before
  public void setUp() {
      myBuggyInstance = new BuggyClass();
  }

  @After
  public void tearDown() {
      myBuggyInstance = null;
  }

  /**
   * k == 3
   */
   @Test
   public void testKEquals3(){
      int rt = myBuggyInstance.buggyMethod1(3);
      assertEquals(rt,-1);
   }

}
