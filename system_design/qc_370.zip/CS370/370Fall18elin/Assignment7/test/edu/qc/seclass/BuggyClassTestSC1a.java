package edu.qc.seclass;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
public class BuggyClassTestSC1a{
  private BuggyClass myBuggyInstance;

  @Before
  public void setUp() {
      myBuggyInstance = new BuggyClass();
  }

  @After
  public void tearDown() {
      myBuggyInstance = null;
  }

  /**
   * k == 1
   */
   @Test
   public void testKEquals1(){
      int rt = myBuggyInstance.buggyMethod1(1);
      assertEquals(rt,10);
   }

   /**
    * k == 2
    */
    @Test
    public void testKEquals2(){
       int rt = myBuggyInstance.buggyMethod1(2);
       assertEquals(rt,5);
    }
}
