package edu.qc.seclass.replace;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.Assert.*;

public class MyMainTest {
	    private ByteArrayOutputStream outStream;
	    private ByteArrayOutputStream errStream;
	    private PrintStream outOrig;
	    private PrintStream errOrig;
	    private Charset charset = StandardCharsets.UTF_8;

	    @Rule
	    public TemporaryFolder temporaryFolder = new TemporaryFolder();

	    @Before
	    public void setUp() throws Exception {
	        outStream = new ByteArrayOutputStream();
	        PrintStream out = new PrintStream(outStream);
	        errStream = new ByteArrayOutputStream();
	        PrintStream err = new PrintStream(errStream);
	        outOrig = System.out;
	        errOrig = System.err;
	        System.setOut(out);
	        System.setErr(err);
	    }

	    @After
	    public void tearDown() throws Exception {
	        System.setOut(outOrig);
	        System.setErr(errOrig);
	    }

	    // Some utilities

	    private File createTmpFile() throws IOException {
	        File tmpfile = temporaryFolder.newFile();
	        tmpfile.deleteOnExit();
	        return tmpfile;
	    }
	    private File createEmptyFile() throws IOException {
	    	    File file1 =  createTmpFile();
		        FileWriter fileWriter = new FileWriter(file1);
		        fileWriter.write("");
		        fileWriter.close();
		        return file1;
	    }
	    

	    private File createInputFile1() throws Exception {
	        File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);

	        fileWriter.write("Howdy Bill,\n" +
	                "This is a test file for the replace utility\n" +
	                "Let's make sure it has at least a few lines\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say \"howdy bill\" again!");

	        fileWriter.close();
	        return file1;
	    }

	    private File createInputFile2() throws Exception {
	        File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);

	        fileWriter.write("Howdy Bill,\n" +
	                "This is another test file for the replace utility\n" +
	                "that contains a list:\n" +
	                "-a) Item 1\n" +
	                "-b) Item 2\n" +
	                "...\n" +
	                "and says \"howdy Bill\" twice");

	        fileWriter.close();
	        return file1;
	    }

	    private File createInputFile3() throws Exception {
	        File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);

	        fileWriter.write("Howdy Bill, have you learned your abc and 123?\n" +
	                "It is important to know your abc and 123," +
	                "so you should study it\n" +
	                "and then repeat with me: abc and 123");

	        fileWriter.close();
	        return file1;
	    }
	    private File createInputFile4()throws Exception{
	    	File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);
	        fileWriter.write("Supposedly there are over one million words in the English Language.\n" +
	                "We trimmed some fat to take away really odd words and determiners.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.");

	        fileWriter.close();
	        return file1;
	    }
	    private File createInputFile5()throws Exception{
	    	File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);

	        fileWriter.write("The fickle map unpacks into the brisk physics.\n" +
	                "The lined dream can't tick the truck.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.");

	        fileWriter.close();
	        return file1;
	    	

	    	
	    }
	    private File createInputFile6()throws Exception{
	    	File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);
	        fileWriter.write("THE WHITE HOUSE is the official residence and workplace of the President of the United States.\n");
	        fileWriter.close();
	        return file1;
	    }
	    
	    private File createInputFile7()throws Exception{
	    	File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);

	        fileWriter.write("The fickle map unpacks into the brisk physics.\n" +
	                "The lined dream can't tick the trucktrucktruck.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.");

	        fileWriter.close();
	        return file1;
	    }
	    private File createShortInputFile() throws Exception {
	        File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);
	        fileWriter.write("Hey Hey Hey Hello Hello Hey\n");

	        fileWriter.close();
	        return file1;
	    }
	    
	    private File createDoubleDashInputFile() throws Exception {
	        File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);
	        fileWriter.write("--THE --WHITE --HOUSE --is --the --official --residence --and " + 
	                         "--workplace --of --the --President --of --the --United --States.\n");

	        fileWriter.close();
	        return file1;
	    }
	    
	    private File createSingleDashInputFile() throws Exception {
	        File file1 =  createTmpFile();
	        FileWriter fileWriter = new FileWriter(file1);
	        fileWriter.write("-THE -WHITE -HOUSE -is -the -official -residence -and " + 
	                         "-workplace -of -the -President -of -the -United -States.\n");

	        fileWriter.close();
	        return file1;
	    }
	    
	   

	    private String getFileContent(String filename) {
	        String content = null;
	        try {
	            content = new String(Files.readAllBytes(Paths.get(filename)), charset);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return content;
	    }
	    
	    // Actual test cases

	    /**
	     * Implementation of test frame #3
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest1() throws Exception {
	    	File inputFile = createShortInputFile();
	    	String args[] = {"Howdy Bill, have you learned your abc and 123?\n, Hello Howdy",
	    			         "Hello","--", inputFile.getPath()};
	    	Main.main(args);
	    	
	    	String expected = "Hey Hey Hey Hello Hello Hey\n";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #16
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest2() throws Exception {
	    	File inputFile = createShortInputFile();
	    	String args[] = {"Hey", "Hello","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Hello Hello Hello Hello Hello Hello\n";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #18
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest3() throws Exception {
	    	File inputFile = createInputFile1();
	    	String args[] = {"again",
	    			         "once more","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Howdy Bill,\n" +
	                "This is a test file for the replace utility\n" +
	                "Let's make sure it has at least a few lines\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say \"howdy bill\" once more!";
	    	
	    	
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #23
	     * @throws Exception
	     */
	    public void myMainTest4() throws Exception {
	    	String args[] = {"again",
			         "once more","--", "xxxx"};
	    	Main.main(args);
	        assertEquals("File " + "xxxx" + " not found", errStream.toString().trim());

	    }
	    
	    /**
	     * Implementation of test frame #1
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest5() throws Exception {
	    	File inputFile1 = createInputFile1();
	        File inputFile2 = createInputFile2();

	        String args[] = {"-b", "-i", "bILl", "William", "--", inputFile1.getPath(), inputFile2.getPath()};
	        Main.main(args);

	        String expected1 = "Howdy William,\n" +
	                "This is a test file for the replace utility\n" +
	                "Let's make sure it has at least a few lines\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say \"howdy William\" again!";
	        String expected2 = "Howdy William,\n" +
	                "This is another test file for the replace utility\n" +
	                "that contains a list:\n" +
	                "-a) Item 1\n" +
	                "-b) Item 2\n" +
	                "...\n" +
	                "and says \"howdy William\" twice";

	        String actual1 = getFileContent(inputFile1.getPath());
	        String actual2 = getFileContent(inputFile2.getPath());

	        assertEquals("The files differ!", expected1, actual1);
	        assertEquals("The files differ!", expected2, actual2);
	        assertTrue(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	        assertTrue(Files.exists(Paths.get(inputFile2.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #5
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest6() throws Exception {
	    	File inputFile = createInputFile4();
	    	String args[] = {"over one million", "none", "--", inputFile.getPath()};
	        Main.main(args);
	        String expected = "Supposedly there are none words in the English Language.\n" +
	                "We trimmed some fat to take away really odd words and determiners.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.";
	        String actual = getFileContent(inputFile.getPath());
	        assertEquals("The files differ!", expected, actual);
	        assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #15
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest7() throws Exception {
	    	File inputFile = createShortInputFile();
	    	String args[] = {"-i","-f","-b","xxx",
	    			         "x","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Hey Hey Hey Hello Hello Hey\n";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #17
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest8() throws Exception {
	    	File inputFile = createInputFile1();
	    	String args[] = {"-f","Bill",
	    			         "again","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Howdy again,\n" +
	                "This is a test file for the replace utility\n" +
	                "Let's make sure it has at least a few lines\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say \"howdy bill\" again!";
	    	
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #9
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest9() throws Exception {
	    	File inputFile = createShortInputFile();
	    	String args[] = {"-b","Hey",
	    			         "hEy","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "hEy hEy hEy Hello Hello hEy\n";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    	
	    }
	    
	    /**
	     * Implementation of test frame #6
	     * @throws Exception
	     */
	    @Test
	    public void myMainTest10() throws Exception {
	    	File inputFile = createInputFile1();
	    	String args[] = {"\"howdy bill\"",
	    			         "bro","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Howdy Bill,\n" +
	                "This is a test file for the replace utility\n" +
	                "Let's make sure it has at least a few lines\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say bro again!";
	    	
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #8
	     * @throws Exception
	     */
	    @Test
	    public void mainTest11() throws Exception {
	    	File inputFile = createInputFile1();
	    	String args[] = {"",
	    			         "","--", inputFile.getPath()};
	        Main.main(args);
	        assertEquals("Usage: Replace [-b] [-f] [-l] [-i] <from> <to> -- <filename> [<filename>]*", errStream.toString().trim());
	    }
	    
	    /**
	     * Implementation of test frame #19
	     * @throws Exception
	     */
	    @Test
	    public void mainTest12() {
	    	String args[] = {"\"howdy bill\"",
			         "bro","--"};
	        Main.main(args);
	        assertEquals("Usage: Replace [-b] [-f] [-l] [-i] <from> <to> -- <filename> [<filename>]*", errStream.toString().trim());
	    }
	    
	    /**
	     * Purpose: To test illegal environment argument 
	     * @throws Exception
	     */
	    @Test
	    public void mainTest13() {
	    	String args[] = {"aaa.txt"};
	        Main.main(args);
	        assertEquals("Usage: Replace [-b] [-f] [-l] [-i] <from> <to> -- <filename> [<filename>]*", errStream.toString().trim());
	    }
	    
	    /**
	     * Purpose: To test from string starting with "-"
	     * @throws Exception
	     */
	    @Test
	    public void mainTest14()throws Exception {
	    	File inputFile = createInputFile2();
	        String args1[] = {"-b", "--", "-a", "1", "--", inputFile.getPath()};
	        Main.main(args1);
	        String args2[] = {"--", "-b", "2", "--", inputFile.getPath()};
	        Main.main(args2);
	        
	        String expected = "Howdy Bill,\n" +
	                "This is another test file for the replace utility\n" +
	                "that contains a list:\n" +
	                "1) Item 1\n" +
	                "2) Item 2\n" +
	                "...\n" +
	                "and says \"howdy Bill\" twice";

	        String actual = getFileContent(inputFile.getPath());

	        assertEquals("The files differ!", expected, actual);
	        assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: To test from string appears more than 3 times, case sensitive
	     * @throws Exception
	     */
	    @Test
	    public void mainTest15() throws Exception{
	    	File inputFile = createInputFile5();
	    	String args[] = {"The",
	    			         "X","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "X fickle map unpacks into the brisk physics.\n" +
	                "X lined dream can't tick the truck.\n" +
	                "so you should study it\n" +
	                "Xn we grabbed the most popular words and built this word randomizer.";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: To test from string appears more than 3 times, case insensitive
	     * @throws Exception
	     */
	    @Test
	    public void mainTest16() throws Exception {
	    	File inputFile = createInputFile5();
	    	String args[] = {"-i","The",
	    			         "X","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "X fickle map unpacks into X brisk physics.\n" +
	                "X lined dream can't tick X truck.\n" +
	                "so you should study it\n" +
	                "Xn we grabbed X most popular words and built this word randomizer.";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #20
	     * @throws Exception
	     */
	    @Test
	    public void mainTest17() throws Exception{
	    	 File inputFile1 = createInputFile1();
	         File inputFile2 = createInputFile2();
	         File inputFile3 = createInputFile3();
	         File inputFile4 = createInputFile4();

	         String args[] = {"-i", "Howdy", "Hello", "--", inputFile1.getPath(), inputFile2.getPath(), inputFile3.getPath()};
	         Main.main(args);

	         String expected1 = "Hello Bill,\n" +
	                 "This is a test file for the replace utility\n" +
	                 "Let's make sure it has at least a few lines\n" +
	                 "so that we can create some interesting test cases...\n" +
	                 "And let's say \"Hello bill\" again!";
	         String expected2 = "Hello Bill,\n" +
	                 "This is another test file for the replace utility\n" +
	                 "that contains a list:\n" +
	                 "-a) Item 1\n" +
	                 "-b) Item 2\n" +
	                 "...\n" +
	                 "and says \"Hello Bill\" twice";
	         String expected3 = "Hello Bill, have you learned your abc and 123?\n" +
	                 "It is important to know your abc and 123," +
	                 "so you should study it\n" +
	                 "and then repeat with me: abc and 123";
	         String expected4 = "Supposedly there are over one million words in the English Language.\n" +
		                "We trimmed some fat to take away really odd words and determiners.\n" +
		                "so you should study it\n" +
		                "Then we grabbed the most popular words and built this word randomizer.";

	         String actual1 = getFileContent(inputFile1.getPath());
	         String actual2 = getFileContent(inputFile2.getPath());
	         String actual3 = getFileContent(inputFile3.getPath());
	         String actual4 = getFileContent(inputFile4.getPath());
	         

	         assertEquals("The files differ!", expected1, actual1);
	         assertEquals("The files differ!", expected2, actual2);
	         assertEquals("The files differ!", expected3, actual3);
	         assertEquals("The files differ!", expected4, actual4);

	         assertFalse(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	         assertFalse(Files.exists(Paths.get(inputFile2.getPath() + ".bck")));
	         assertFalse(Files.exists(Paths.get(inputFile3.getPath() + ".bck")));
	         assertFalse(Files.exists(Paths.get(inputFile4.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: To test empty file
	     * @throws Exception
	     */
	    @Test
	    public void mainTest18() throws Exception {
	    	File inputFile = createEmptyFile();
	    	String args[] = {"-i","The",
	    			         "X","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Implementation of test frame #95
	     * @throws Exception
	     */
	    @Test
	    public void mainTest19() throws Exception {
	    	File inputFile = createInputFile6();
	    	String args[] = {"-b","WHITE HOUSE",
	    			         "White House","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "THE White House is the official residence and workplace of the President of the United States.\n";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: To test From string contains only one character
	     * @throws Exception
	     */
	    @Test
	    public void mainTest20() throws Exception {
	    	File inputFile = createShortInputFile();
	    	String args[] = {"-b","H",
	    			         "K","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Key Key Key Kello Kello Key\n";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: illegal environment variable
	     * @throws Exception
	     */
	    @Test
	    public void mainTest21(){
	    	String args[] = {"--","input.txt"};
	        Main.main(args);
	        assertEquals("Usage: Replace [-b] [-f] [-l] [-i] <from> <to> -- <filename> [<filename>]*", errStream.toString().trim());
	    }
	    
	    /**
	     * Purpose: to Test from string appearing on the first word
	     * @throws Exception
	     */
	    @Test
	    public void mainTest22() throws Exception {
	    	File inputFile = createInputFile4();
	    	String args[] = {"Supposedly","Assuming","--",inputFile.getPath()};
	    	Main.main(args);
	    	String expected = 
	    			"Assuming there are over one million words in the English Language.\n" +
	                "We trimmed some fat to take away really odd words and determiners.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.";
	    	String actual = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    	
	    }
	    
	    /**
	     * Purpose: to Test from string appearing on the last word
	     * @throws Exception
	     */
	    @Test
	    public void mainTest23() throws Exception {
	    	File inputFile = createInputFile4();
	    	String args[] = {"-b","randomizer",
	    			         "generator","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Supposedly there are over one million words in the English Language.\n" +
	                "We trimmed some fat to take away really odd words and determiners.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word generator.";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to Test from string equals the whole text content
	     * @throws Exception
	     */
	    @Test
	    public void mainTest24() throws Exception {
	    	File inputFile = createShortInputFile();
	    	String args[] = {"-b","Hey Hey Hey Hello Hello Hey\n",
	    			         "K","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "K";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test continuous occurrence of from string in the text file 
	     * @throws Exception
	     */
	    @Test
	    public void mainTest25() throws Exception {
	    	File inputFile = createInputFile7();
	    	String args[] = {"-b","truck",
	    			         "car","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "The fickle map unpacks into the brisk physics.\n" +
	                "The lined dream can't tick the carcarcar.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test the from string containing single quote
	     * @throws Exception
	     */
	    @Test
	    public void mainTest26() throws Exception {
	    	File inputFile = createInputFile7();
	    	String args[] = {"can't",
	    			         "can","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "The fickle map unpacks into the brisk physics.\n" +
	                "The lined dream can tick the trucktrucktruck.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test the from string containing single quote
	     * @throws Exception
	     */
	    @Test
	    public void mainTest27() throws Exception {
	    	File inputFile = createInputFile7();
	    	String args[] = {"can't",
	    			         "x","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "The fickle map unpacks into the brisk physics.\n" +
	                "The lined dream x tick the trucktrucktruck.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words and built this word randomizer.";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test the from string containing double quote
	     * @throws Exception
	     */
	    @Test
	    public void mainTest28() throws Exception {
	    	File inputFile = createInputFile1();
	    	String args[] = {"\"howdy bill\"",
	    			         "how are you bill","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = "Howdy Bill,\n" +
	                "This is a test file for the replace utility\n" +
	                "Let's make sure it has at least a few lines\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say how are you bill again!";
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose:  to test the four options all applied
	     * @throws Exception
	     */
	    @Test
	    public void mainTest29() throws Exception {
	    	File inputFile = createInputFile7();
	    	String args[] = {"-b","-i","-f","-l","the",
	    			         "a","--", inputFile.getPath()};
	    	Main.main(args);
	    	String expected = 
	    			"a fickle map unpacks into the brisk physics.\n" +
	    		            "The lined dream can't tick the trucktrucktruck.\n" +
	    		            "so you should study it\n" +
	    		            "Then we grabbed a most popular words and built this word randomizer.";
	    	
	    	String actual   = getFileContent(inputFile.getPath());
	    	assertEquals("The files differ!",expected,actual);
	    	assertTrue(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test from string begins with "--"
	     * @throws Exception
	     */
	    @Test
	    public void mainTest30() throws Exception {
	    	File inputFile = createDoubleDashInputFile();
	        String args1[] = {"--", "--x", "-x", "--", inputFile.getPath()};
	        Main.main(args1);
	        String args2[] = {"--", "--", "-", "--", inputFile.getPath()};
	        Main.main(args2);
	        
	        String expected = "-THE -WHITE -HOUSE -is -the -official -residence -and " + 
                    "-workplace -of -the -President -of -the -United -States.\n";

	        String actual = getFileContent(inputFile.getPath());

	        assertEquals("The files differ!", expected, actual);
	        assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test from string begins with "-"
	     * @throws Exception
	     */
	    @Test
	    public void mainTest31() throws Exception {
	    	File inputFile = createSingleDashInputFile();
	        String args1[] = {"--", "--x", "-x", "--", inputFile.getPath()};
	        Main.main(args1);
	        String args2[] = {"--", "-", "x", "--", inputFile.getPath()};
	        Main.main(args2);
	        
	        String expected = "xTHE xWHITE xHOUSE xis xthe xofficial xresidence xand " + 
                    "xworkplace xof xthe xPresident xof xthe xUnited xStates.\n";

	        String actual = getFileContent(inputFile.getPath());

	        assertEquals("The files differ!", expected, actual);
	        assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test multiple occurrence of from string, multiple files applied
	     * @throws Exception
	     */
	    @Test
	    public void mainTest32() throws Exception {
	    	 File inputFile1 = createInputFile4();
	         File inputFile2 = createInputFile5();


	         String args[] = {"-i", "and", "not", "--", inputFile1.getPath(), inputFile2.getPath()};
	         Main.main(args);


		     String expected1 = 
		    		"Supposedly there are over one million words in the English Language.\n" +
	                "We trimmed some fat to take away really odd words not determiners.\n" +
	                "so you should study it\n" +
	                "Then we grabbed the most popular words not built this word rnotomizer.";
	         String expected2 =       	
	        		"The fickle map unpacks into the brisk physics.\n" +
			                "The lined dream can't tick the truck.\n" +
			                "so you should study it\n" +
			                "Then we grabbed the most popular words not built this word rnotomizer.";

	         String actual1 = getFileContent(inputFile1.getPath());
	         String actual2 = getFileContent(inputFile2.getPath());
	        
	         assertEquals("The files differ!", expected1, actual1);
	         assertEquals("The files differ!", expected2, actual2);
	         assertFalse(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	         assertFalse(Files.exists(Paths.get(inputFile2.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test multiple empty text file
	     * @throws Exception
	     */
	    @Test
	    public void mainTest33() throws Exception {
	    	 File inputFile1 = createEmptyFile();
	         File inputFile2 = createEmptyFile();

	         String args[] = {"-i", "and", "not", "--", inputFile1.getPath(), inputFile2.getPath()};
	         Main.main(args);

		     String expected1 = "";
	         String expected2 = "";

	         String actual1 = getFileContent(inputFile1.getPath());
	         String actual2 = getFileContent(inputFile2.getPath());
	        
	         assertEquals("The files differ!", expected1, actual1);
	         assertEquals("The files differ!", expected2, actual2);
	         assertFalse(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	         assertFalse(Files.exists(Paths.get(inputFile2.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test normal use, from string occurrence on any position
	     * @throws Exception
	     */
	    @Test
	    public void mainTest34() throws Exception {
	    	File inputFile1 = createInputFile1();
	    
	        String args[] = {"-b", "-i", "file", "document", "--", inputFile1.getPath()};
	        Main.main(args);

	        String expected1 = "Howdy Bill,\n" +
	                "This is a test document for the replace utility\n" +
	                "Let's make sure it has at least a few lines\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say \"howdy bill\" again!";
	        
	        String actual1 = getFileContent(inputFile1.getPath());
	        assertEquals("The files differ!", expected1, actual1);
	        assertTrue(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test normal use, from string occurrence on any position
	     * @throws Exception
	     */
	    @Test
	    public void mainTest35() throws Exception {
	    	   File inputFile1 = createInputFile2();
	    	   String args[] = {"-b", "-i", "replace", "substitute", "--",inputFile1.getPath()};
	           Main.main(args);
	           String expected1 = "Howdy Bill,\n" +
	                "This is another test file for the substitute utility\n" +
	                "that contains a list:\n" +
	                "-a) Item 1\n" +
	                "-b) Item 2\n" +
	                "...\n" +
	                "and says \"howdy Bill\" twice";
	           String actual1 = getFileContent(inputFile1.getPath());
	           assertEquals("The files differ!", expected1, actual1);
		       assertTrue(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test normal use, from string occurrence on any position
	     * @throws Exception
	     */
	    @Test
	    public void mainTest36() throws Exception {
	    	File inputFile1 = createInputFile2();
	    	   String args[] = {"-b", "-i", "Item", "Object", "--",inputFile1.getPath()};
	           Main.main(args);
	           String expected1 = "Howdy Bill,\n" +
	                "This is another test file for the replace utility\n" +
	                "that contains a list:\n" +
	                "-a) Object 1\n" +
	                "-b) Object 2\n" +
	                "...\n" +
	                "and says \"howdy Bill\" twice";
	           String actual1 = getFileContent(inputFile1.getPath());
	           assertEquals("The files differ!", expected1, actual1);
		       assertTrue(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test normal use, from string contains multiple words
	     * @throws Exception
	     */
	    @Test
	    public void mainTest37() throws Exception {
	    	File inputFile1 = createInputFile2();
	    	   String args[] = {"-b", "-i", "test file for the replace utility", 
	    			            "test for nothing", "--",inputFile1.getPath()};
	           Main.main(args);
	           String expected1 = "Howdy Bill,\n" +
		                "This is another test for nothing\n" +
		                "that contains a list:\n" +
		                "-a) Item 1\n" +
		                "-b) Item 2\n" +
		                "...\n" +
		                "and says \"howdy Bill\" twice";
	           
	           String actual1 = getFileContent(inputFile1.getPath());
	           assertEquals("The files differ!", expected1, actual1);
		       assertTrue(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test normal use, from string contains multiple words
	     * @throws Exception
	     */
	    @Test
	    public void mainTest38() throws Exception {
	    	File inputFile1 = createInputFile1();
		    
	        String args[] = {"-b", "-i", "Let's make sure it has at least a few lines", 
	        		         "document", "--", inputFile1.getPath()};
	        Main.main(args);

	        String expected1 = "Howdy Bill,\n" +
	                "This is a test file for the replace utility\n" +
	                "document\n" +
	                "so that we can create some interesting test cases...\n" +
	                "And let's say \"howdy bill\" again!";
	        
	        String actual1 = getFileContent(inputFile1.getPath());
	        assertEquals("The files differ!", expected1, actual1);
	        assertTrue(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	    }
	    
	    /**
	     * Purpose: to test normal use, from string contains multiple words, on multiple files
	     * @throws Exception
	     */
	    @Test
	    public void mainTest39() throws Exception {
	    	File inputFile1 = createInputFile7();
	         File inputFile2 = createInputFile5();


	         String args[] = {"-i", "The lined dream can't tick the truck", 
	        		                "nothing", "--", inputFile1.getPath(), inputFile2.getPath()};
	         Main.main(args);


		     String expected1 = 
		    		 "The fickle map unpacks into the brisk physics.\n" +
		 	                "nothingtrucktruck.\n" +
		 	                "so you should study it\n" +
		 	                "Then we grabbed the most popular words and built this word randomizer.";
	         String expected2 =       	
	        		 "The fickle map unpacks into the brisk physics.\n" +
	     	                "nothing.\n" +
	     	                "so you should study it\n" +
	     	                "Then we grabbed the most popular words and built this word randomizer.";

	         String actual1 = getFileContent(inputFile1.getPath());
	         String actual2 = getFileContent(inputFile2.getPath());
	        
	         assertEquals("The files differ!", expected1, actual1);
	         assertEquals("The files differ!", expected2, actual2);
	         assertFalse(Files.exists(Paths.get(inputFile1.getPath() + ".bck")));
	         assertFalse(Files.exists(Paths.get(inputFile2.getPath() + ".bck")));
	    	
	                
			
	    }
	    
	    /**
	     * Purpose: to test when from string starts with "-"
	     * @throws Exception
	     */
	    @Test
	    public void mainTest40() throws Exception {
	    	File inputFile = createSingleDashInputFile();
	        String args1[] = {"--", "--x", "-x", "--", inputFile.getPath()};
	        Main.main(args1);
	        String args2[] = {"--", "-", "", "--", inputFile.getPath()};
	        Main.main(args2);
	        
	        String expected = "THE WHITE HOUSE is the official residence and " + 
                    "workplace of the President of the United States.\n";

	        String actual = getFileContent(inputFile.getPath());

	        assertEquals("The files differ!", expected, actual);
	        assertFalse(Files.exists(Paths.get(inputFile.getPath() + ".bck")));
	    }
	    
}
