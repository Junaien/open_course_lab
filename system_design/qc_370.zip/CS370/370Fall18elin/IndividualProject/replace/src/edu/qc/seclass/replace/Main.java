package edu.qc.seclass.replace;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
public class Main {
	private static Charset charset = StandardCharsets.UTF_8;
    public static void main(String[] args){
    	//edge case
    	if(args == null || args.length == 0){
    		usage();
    		return;
    	}
    	
    	//initialization, check optional flags' existence
    	boolean flagI = false, flagB = false, flagF = false, flagL = false;
    	int argumentSize = args.length;
    	int parameterPointer = 0;
        while(parameterPointer < args.length && args[parameterPointer].startsWith("-")) {	
			if(args[parameterPointer].equals("--")) {parameterPointer++; break;}
			else if(args[parameterPointer].equals("-b")) flagB =true;
			else if(args[parameterPointer].equals("-i")) flagI =true;
			else if(args[parameterPointer].equals("-l")) flagL =true;
			else if(args[parameterPointer].equals("-f")) flagF =true;
			else {
				usage();
				return;
			}
			parameterPointer++;	
    	}
       
           
    	//check the parameter for (fromString toString)+
        if(argumentSize - parameterPointer < 3) {
        	usage();
        	return;
        }
        List<String> fromString = new ArrayList<>();
        List<String> toString   = new ArrayList<>();
        parameterPointer = takeFromToStringPair(fromString,toString,args,parameterPointer);
        if(parameterPointer == -1) {
        	usage();
        	return;
        }
        while(parameterPointer <= argumentSize - 2 && !args[parameterPointer].equals("--")){
        	parameterPointer = takeFromToStringPair(fromString,toString,args,parameterPointer);
        	 if(parameterPointer == -1) {
             	usage();
             	return;
             }
        }
        
        //check the (fromString, toString) terminal "--" indicator
        if(parameterPointer >= args.length || !args[parameterPointer].equals("--")) {
        	usage();
        	return;
        }else {
        	parameterPointer++;
        }
    	
    	//check the parameter for filenName*;
        if(parameterPointer >= argumentSize) {
    		usage();
    		return;
    	}
    	List<String> files = new ArrayList<>();
    	for(int i = parameterPointer; i < argumentSize; i++) {
    		files.add(args[i]);
    	}
    	
    	//process every file
    	for(String file:files) {
    		for(int i = 0; i < fromString.size();i++) {
    			replace(flagI, flagB, flagF, flagL,fromString.get(i), toString.get(i),file);
    		}
    	}
    	
    	
    }
    private static int takeFromToStringPair(List<String> from, List<String> to, String[] args,int parameterPointer) {
    	if(args[parameterPointer].equals("")) {
    		return -1;
    	}else {
    		from.add(args[parameterPointer++]);
    	}
    	to.add(args[parameterPointer++]);
    	return parameterPointer;
    }
    private static void replace(boolean flagI, boolean flagB, boolean flagF, boolean flagL, 
    		                    String  fromString, String toString, String file){
    	Path path = null;
    	try {
    		path = Paths.get(file);
    		String content = new String(Files.readAllBytes(path), charset);
    		FileWriter fw = null;
    		
    		//check if backup flag turn on
    		if(flagB){
    			//check if back up already exist
    			File fbck = new File(file +".bck"); 
    			if(fbck.exists() && !fbck.isDirectory()) {
    				System.err.println("Not performing replace for " + path.getFileName() + ": Backup file already exists");
    				return;
    			}else {
    				fw = new FileWriter(fbck);
        	        fw.write(content);
        	        fw.close();	
    			}		
    		}
    		fw = new FileWriter(new File(file));
    		String fromStringI = "(?i)" + fromString;
			if((!flagF && !flagL)){	   			
				content = content.replaceAll(flagI? fromStringI:fromString, toString);		
			}else if(flagF && flagL){
				content = content.replaceFirst(flagI? fromStringI:fromString,toString);
				int lastIndex = flagI?  content.toLowerCase().lastIndexOf(fromString.toLowerCase())
									   :content.lastIndexOf(fromString);
				if(lastIndex != -1) {
					String lastPart = content.substring(lastIndex);
					content = content.substring(0, lastIndex) 
							  + 
							  lastPart.replaceFirst(flagI? fromStringI:fromString,toString);
				}
			}else if(flagF) {
				content = content.replaceFirst(flagI? fromStringI:fromString,toString);
				
			}else {
				int lastIndex = flagI?  content.toLowerCase().lastIndexOf(fromString.toLowerCase())
						   :content.lastIndexOf(fromString);
				if(lastIndex != -1) {
					String lastPart = content.substring(lastIndex);
					content = content.substring(0, lastIndex) 
							  + 
							  lastPart.replaceAll(flagI? fromStringI:fromString,toString);
				}
				
			}
	        fw.write(content);
	        fw.close();
    		
    	}catch(InvalidPathException | IOException e) {
    		fileNotFoundMessage(path.getFileName().toString());
    	}catch(Exception e) {
    		System.out.println("fail to replace file " + file);
    	}
    	
    	return;
    }

    private static void usage() {
        System.err.println("Usage: Replace [-b] [-f] [-l] [-i] <from> <to> -- " + "<filename> [<filename>]*" );
    }
    private static void fileNotFoundMessage(String file) {
        System.err.println("File " + file + " not found");
    	
    }
    
   
   

}