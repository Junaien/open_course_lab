1. A list consisting of reminders the users want to be aware of. The application must allow
users to add reminders to a list, delete reminders from a list, and edit the reminders in
the list.
- There are a User and ReminderList Class that represent users and the reminder lists
   he/she has. One user is related to many reminders list
- ReminderList class has operations "addReminder" and "removeReminder"
- UserReminder class has operation "editReminder"

2. The application must contain a database (DB) of reminders and corresponding data.
- I added to the design UserReminder and templateReminder class, which contains attributes
      reminderName, isCheckOff(to indicate its state), alertLocation (to
      indicate its alert location) and so on.

3. Users must be able to add reminders to a list by picking them from a hierarchical list,
where the first level is the reminder type (e.g., Appointment), and the second level is the
name of the actual reminder (e.g., Dentist Appointment).
- I added the reminderType class to represent the first level hierarchical
- I also add an templateReminder class, one reminderType is associated with
   many templateReminders that the user can pick

4. Users must also be able to specify a reminder by typing its name. In this case, the
application must look in its DB for reminders with similar names and ask the user
whether that is the item they intended to add. If a match (or nearby match) cannot be
found, the application must ask the user to select a reminder type for the reminder, or
add a new one, and then save the new reminder, together with its type, in the DB.
- I added the operation "addNewType" in reminderType class for user to add new Type
- I made UserReminder class a subclass of templateReminder to separate the role of user reminder
   and system reminder template

5. The reminders must be saved automatically and immediately after they are modified.
- I added "save" operation in templateReminder class for synchronizing the object with database

6. Users must be able to check off reminders in the list (without deleting them).
- UserReminder class has a attribute "isCheckOff" that can be turned on and off
- UserReminder class has operation "checkOff"

7. Users must also be able to clear all the check-off marks in the reminder list at once.
- ReminderList class has a operation "clearAllCheckOffMarks"

8. Check-off marks for the reminder list are persistent and must also be saved immediately.
- in UserReminder class we have "isCheckOff" attribute, which stores this information in DB

9. The application must present the reminders grouped by type.
- One ReminderType is associated with many templateReminders or UserReminders, we can display
   all the reminders that are associated with a specific reminder type.

10. The application must support multiple reminder lists at a time (e.g., “Weekly”, “Monthly”,
“Kid’s Reminders”). Therefore, the application must provide the users with the ability to
create, (re)name, select, and delete reminder lists.
- one user is associated with many reminder lists
- we have operation "rename" in ReminderList class
- we have operations "createReminderList", "selectReminderList" and "deleteReminderList"
   in User class

11. The application should have the option to set up reminders with day and time alert. If this
option is selected allow option to repeat the behavior.
- I added a attribute "alertDay", which is a set, and "alertTime" in UserReminder class
   System can alert user based on those attributes.
   
12. Extra Credit: Option to set up reminder based on location.
- I added a attribute "alertLocation" in UserReminder class
   System can alert user based on this attribute
   
13. The User Interface (UI) must be intuitive and responsive.
- Not considered because it does not affect the design directly
