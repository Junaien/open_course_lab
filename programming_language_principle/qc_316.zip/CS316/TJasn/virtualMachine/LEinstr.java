package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class LEinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public LEinstr ()
  {
    super("LE");
  }
}

