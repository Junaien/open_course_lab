package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class GTinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public GTinstr ()
  {
    super("GT");
  }
}

