package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class EQinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public EQinstr ()
  {
    super("EQ");
  }
}

