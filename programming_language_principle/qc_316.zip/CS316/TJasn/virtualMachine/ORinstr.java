package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class ORinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public ORinstr ()
  {
    super("OR");
  }
}

