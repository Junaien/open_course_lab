package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class ANDinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public ANDinstr ()
  {
    super("AND");
  }
}
