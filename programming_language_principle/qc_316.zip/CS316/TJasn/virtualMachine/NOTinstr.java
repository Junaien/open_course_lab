package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class NOTinstr extends ZeroOperandInstruction {

  void execute ()
  {
     /* ???????? */
  }

  public NOTinstr ()
  {
    super("NOT");
  }
}
