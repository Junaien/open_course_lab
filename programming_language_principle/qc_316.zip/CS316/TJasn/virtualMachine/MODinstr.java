package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class MODinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public MODinstr ()
  {
    super("MOD");
  }
}

