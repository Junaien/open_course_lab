package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class DIVinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public DIVinstr ()
  {
    super("DIV");
  }
}
