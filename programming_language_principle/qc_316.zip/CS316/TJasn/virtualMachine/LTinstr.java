package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class LTinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public LTinstr ()
  {
    super("LT");
  }
}
