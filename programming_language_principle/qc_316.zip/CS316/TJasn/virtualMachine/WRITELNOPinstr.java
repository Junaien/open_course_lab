package TJasn.virtualMachine;

public class WRITELNOPinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public WRITELNOPinstr ()
  {
    super("WRITELNOP");
  }
}
