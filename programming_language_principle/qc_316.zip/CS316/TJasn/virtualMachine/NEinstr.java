package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class NEinstr extends ZeroOperandInstruction {

  void execute ()
  {
     /* ???????? */
  }

  public NEinstr ()
  {
    super("NE");
  }
}
