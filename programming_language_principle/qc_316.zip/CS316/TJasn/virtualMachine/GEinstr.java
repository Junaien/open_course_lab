package TJasn.virtualMachine;

import static TJasn.virtualMachine.CodeInterpreter.*;

public class GEinstr extends ZeroOperandInstruction {

  void execute ()
  {
    /* ???????? */
  }

  public GEinstr ()
  {
    super("GE");
  }
}

