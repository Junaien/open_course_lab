Usage:
1: g++ safe_array.cpp -std=c++11
2: run ./a.out
3: there should be no errors, all tests should pass