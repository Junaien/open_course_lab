Usage:
1: g++ inverted_index.cpp -std=c++11
2: run ./a.out
3: the index info should be printed on standard output