Usage:
1: g++ safe_matrix.cpp -std=c++11
2: run ./a.out