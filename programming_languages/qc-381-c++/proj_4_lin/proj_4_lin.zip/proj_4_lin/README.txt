Usage:
1: run g++ polynomial.cpp -std=c++11
2: run ./a.out
3: check output.txt