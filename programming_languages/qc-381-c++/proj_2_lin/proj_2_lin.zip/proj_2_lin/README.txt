Usage:
1: run g++ polynomial.cpp
2: run ./a.out
3: check output.txt