import java.util.Random;
public class RyanRules extends Thread{

	public static long startTime = System.currentTimeMillis();
	public static String name;

	public RyanRules(String Name){
		name = Name;
	}

	@Override
	public void run(){

		while(true){
			System.out.println(Thread.currentThread().getName() + " is currently running.");
			Random generator = new Random();
			int sleepTime = generator.nextInt(5) + 1;
			sleepTime = sleepTime * 1000;
			System.out.println(Thread.currentThread().getName() + " is currently sleeping for : " + sleepTime);
			System.out.println (Thread.currentThread().getName() + " has been running for : " + age() + " Milliseconds.");
			try {
				sleep(sleepTime);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	protected static final long age() {
		return System.currentTimeMillis() - startTime;
	}

}

