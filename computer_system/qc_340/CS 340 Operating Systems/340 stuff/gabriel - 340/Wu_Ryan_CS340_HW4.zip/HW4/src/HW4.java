

public class HW4 extends Thread {
	
	public static long startTime = System.currentTimeMillis();
	public static String name;
	
	public HW4(String Name){
		name = Name;
	}
	
	public static void main (String [] args){
		Thread Ryan = new Thread(new Ryan("Ryan"));
		Thread RyanRules = new Thread(new RyanRules("RyanRules"));
		Thread RyanNeedsAnA = new Thread(new RyanNeedsAnA("RyanNeedsAnA"));
		Ryan.setName("Ryan");
		RyanRules.setName("Ryan Rules");
		RyanNeedsAnA.setName("Ryan Needs An A ");
		Ryan.start();
		RyanRules.start();
		RyanNeedsAnA.start();

	}

}
