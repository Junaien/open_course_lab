package javaThreads;

public class TheAdventure {
	private int count =0;
	private boolean isDragonBusy = false;		//make the dragon wait
	private boolean isInBattle=false;			//let the adventurer know he has to wait
	private boolean isGameOver=false;			//tell the clerk and dragon to go home
	private boolean need_assistance =false;		//clerk wait for adventurer 
	private boolean isServing=false;			//serving a player
	private boolean isItheWinner=false;
	public String helperArray[]= new String[]{"stone", "ring","necklaces", "magical ring","magical necklace" };

	
	//setters, when changing data should be synchronized 
	public synchronized void setAvailable(boolean tf){isDragonBusy=tf;}
	
	public synchronized void setIsInBattle(boolean tf){isInBattle=tf;}
	
	public synchronized void setIsSeving(boolean tf){isServing=tf;}
	
	public synchronized void setIsGameOver(boolean tf){isGameOver=tf;}
	
	public synchronized void setIsItheWinner(boolean tf){isItheWinner=tf;}
	
	public synchronized void setNeed_assistance(boolean tf){need_assistance=tf;}
	
	//getter
	public synchronized boolean getAvailable(){return isDragonBusy;}
	
	public synchronized boolean isInBattle(){return isInBattle;}
	
	public synchronized boolean isGameOver(){return isGameOver;}
	
	public synchronized boolean isServing(){return isServing;}
	
	public synchronized boolean isItheWinner(){return isItheWinner;}
	
	public synchronized boolean getNeed_assistance(){return need_assistance;}

	
	//functions 
	public synchronized void getReadToStart()throws InterruptedException
	{
		this.wait();
	}
	
	public synchronized void startAdvanture(){
		this.notifyAll();
	}
	
	public synchronized int numberOfThreads(){
		return ++count;
	}
	

}
