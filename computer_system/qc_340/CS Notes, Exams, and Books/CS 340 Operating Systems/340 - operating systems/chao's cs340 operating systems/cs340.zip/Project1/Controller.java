import java.util.*;

/*
CSCI 340 6:30 - 7:45pm 
Project 1
By: Yachao Liu
April 7, 2008
*/


public class Controller implements Runnable{
	
	Project1 main;
	Vector carOrder;
	
	public Controller(Project1 m){
		//carOrder = new Vector(m.numCar);
		main = m;
	}//constructor
	
	public void printMessage(String message){
		String threadName = Thread.currentThread().getName();
		startTime();
		System.out.print(threadName + ":" + message);
		System.out.println();
	}//printMessage
	
	public static final void startTime(){
		int hour = 0, minute = 0, second = 0;
		Calendar current = Calendar.getInstance();
		current.setTimeInMillis(System.currentTimeMillis());
		hour = current.get(Calendar.HOUR);
		minute = current.get(Calendar.MINUTE);
		second = current.get(Calendar.SECOND);
		System.out.print(hour + ":" + minute + ":" + second + " -- ");
	}//startTime
	
	public void run(){
		Random generator = new Random();
		int sleepTime = 0;//random sleep time
		
		sleepTime = generator.nextInt(1000) + 500;//sleep 2-3 
		
		try{
		printMessage("Arrives at the depot and ready to work");
		/*
			while(main.c){
				//if no cars are ready the controller busy waits
				printMessage("Waiting for available cars...");
				Thread.sleep(1000);//sleep for 1 sec
			}//while
			
		*/
		
		}//try
		catch(Exception e){
			System.out.println("Controller thread error");
			e.printStackTrace();
		}//catch
		
	}//run
	
}//Controller