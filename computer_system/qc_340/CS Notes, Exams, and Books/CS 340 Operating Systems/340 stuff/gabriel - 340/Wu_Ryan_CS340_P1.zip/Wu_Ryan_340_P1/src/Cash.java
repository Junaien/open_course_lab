//Ryan Wu
//CS340

import java.util.Random;

public class Cash extends Thread {
	
	private static Random generator = new Random();
	
	public synchronized static void goCash() {
		Commuting.msg(":is going through toll.");
		int sleepTime = generator.nextInt(10)+1;
		sleepTime = sleepTime*1000;
		try {
			Commuting.msg(":it will take " + sleepTime + " milliseconds to pass through toll.");
			sleep(sleepTime);
			Commuting.msg(": passed through toll at " + Commuting.age() + " milliseconds.");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}