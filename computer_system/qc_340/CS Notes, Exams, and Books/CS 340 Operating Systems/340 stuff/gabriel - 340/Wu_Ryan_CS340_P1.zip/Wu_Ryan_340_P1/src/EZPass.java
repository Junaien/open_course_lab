//Ryan Wu
//CS340

import java.util.Random;

public class EZPass extends Thread {
	
	private static Random generator = new Random();
	
	public synchronized static void goEZPass() {
		Commuting.msg(":going through EZPass.");
		int sleepTime = generator.nextInt(10)+1;
		sleepTime = sleepTime*1000;
		try {
			Commuting.msg(":it will take " + sleepTime + " milliseconds to pass through EZPass.");
			sleep(sleepTime);
			Commuting.msg(": passed through EZPass at " + Commuting.age() + " milliseconds.");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
