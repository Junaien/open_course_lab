//Ryan Wu
//CS340

public class Working {
	private static int Waiting = 0;
	
	public synchronized void currWorking(){
		Waiting ++;
		Commuting.msg(":is currently working at " + Commuting.age() + " milliseconds.");
		
		while(true) {
			try {
				wait();
				break;
			} catch (InterruptedException e) {
				
			}
		}
	}
	public void arriveAtWork() {
		synchronized(this) {
			Commuting.msg(":arrived at work at " + Commuting.age() + " milliseconds.");
			
			notify();
		}
	}
	
	public static int getWait(){
		return Waiting;
	}
	
	public static void setWait(int num){
		Waiting = num;
	}

}
