//Ryan Wu
//CS340

import java.util.Random;

public class Commuting extends Thread {
	private static Random generator = new Random();
	private static int countName = 0;
	private static int numToPark;
	private static long time = System.currentTimeMillis();
	public static int Commuters = Main.getCommuters();
	public static int finished = 0;
	public static int done;


	@Override
	public void run() {

		Thread.currentThread().setName("Commuter " + countName++);
		if(countName % 2 == 0){
			int sleepTime = generator.nextInt(10)+ 1;
			sleepTime = sleepTime*1000;
			try {
				msg(" :does not have to leave for work yet.");
				sleep(sleepTime);
				
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		msg(" :is currently starting commute at " + Commuting.age() + " milliseconds.");
		try {
			int sleepTime = generator.nextInt(10) + 1;
			sleepTime = sleepTime*1000;
			msg(" :is currently driving on local streets and will take " 
					+ sleepTime + " milliseconds to reach the main boulevard.");
			Thread.currentThread();
			Thread.sleep(sleepTime);
			MainRoad();
			AvoidTrucks();
			PassRedLight();
			ArriveAtBridge();
			TollBooth();
			ArriveInManhattan();
			Park();
			Main.WORKING.arriveAtWork();
			Main.WORKING.currWorking();
			finished ++;
			done = Commuters - finished;
			leaveWork();			
			if(done == 1){
				new Release().start();
			}

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void PassRedLight(){
		int passedRed = generator.nextInt(100) + 1;
		if(passedRed % 2 == 0){
			msg(":passed Red Light, Slowing down.");
			Thread.currentThread().setPriority(5);
		}
		else{
			msg(":is going to fast and does not want to get a ticket.");
			int slowDown = generator.nextInt(5) + 1;
			slowDown = slowDown * 1000;
			msg(":slowing down in " + slowDown+ " milliseconds.");
			try {
				sleep(slowDown);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void MainRoad(){
		msg(":has reached the main boulevard at " + Commuting.age() + " milliseconds.");
		Thread.yield();
	}

	public static void AvoidTrucks(){
		int numOfCars = generator.nextInt(10) + 1;
		int timeToPass = numOfCars * 1000;
		msg(":must avoid double-parked trucks.");
		msg(":must pass " + numOfCars + " cars and it will take " 
				+ timeToPass + " milliseconds to pass the cars.");
		Thread.currentThread().setPriority(MAX_PRIORITY);

	}

	public static void ArriveAtBridge(){
		msg(":has arived at the Bridge at " + Commuting.age() + " milliseconds.");

	}

	public synchronized void TollBooth(){

		int pass = generator.nextInt(9) + 1;

		if(pass < 5 ){
			Cash.goCash();

		}
		else{
			EZPass.goEZPass();
		}
	}

	public static void ArriveInManhattan(){
		msg(":arrived in Manhattan at " + Commuting.age() + " milliseconds.");
	}

	public static void Park(){
		numToPark = Main.getCapacity();
		if(numToPark > 0){
			numToPark--;
			Main.setCapacity(numToPark);
			msg(":parking in Garage at " + Commuting.age() + " milliseconds.");
		}
		else{
			int sleepTime = generator.nextInt(20) + 1;
			sleepTime = sleepTime * 1000;
			msg(":is waiting for parking.");
			try {
				sleep(sleepTime);
				if(numToPark < 1){
					msg(":parking on the street at " + Commuting.age() + " milliseconds.");
				}
				else{
					msg(":has found a free parking space. Going to park in Garage at " + Commuting.age() + " milliseconds.");
					numToPark --;
					Main.setCapacity(numToPark);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public synchronized static void leaveWork(){
		msg(":is done with shift work at " + age() + " milliseconds. Leaving to go home.");
		int freePark = generator.nextInt(100) + 1;
		if(freePark %2 == 0){
			numToPark++;
			Main.setCapacity(numToPark);
		}

	}

	public synchronized static void goHome(){
		int sleepTime = generator.nextInt(10) + 1;
		sleepTime = sleepTime*1000;
		try {
			sleep(sleepTime);
			msg(":has returned home at " + age() + ".");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public static long age(){
		return System.currentTimeMillis() - time;
	}

	public static void msg(String m) {
		System.out.println("[" + age() +"] "+ Thread.currentThread().getName()+ " " +m);
	}

}
