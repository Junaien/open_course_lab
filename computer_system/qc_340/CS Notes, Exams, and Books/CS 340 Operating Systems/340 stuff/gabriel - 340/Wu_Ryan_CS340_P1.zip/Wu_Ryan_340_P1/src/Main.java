//Ryan Wu
//CS340

public class Main extends Thread {

	private static int numCommuters = 15;
	private static int garageCapacity = 4;
	public static Working WORKING = new Working();
	
	public static void main ( String[] args){

		if(args.length <= 0){
			System.out.println("Number of commuters will be set to 15 and garage capacity will be set to 4.");
		}
		else{
			numCommuters = Integer.parseInt(args[0]);
			garageCapacity = Integer.parseInt(args[1]);
		}
		
		new AlreadyWorking().start();
		
		for( int i = 1 ; i <= numCommuters; i++){
		    new Commuting().start();
		}
		
		if(Thread.currentThread().isAlive()){
			try {
				Thread.currentThread().join(15000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}		
	
	public static int getCommuters(){
		return numCommuters;
	}

	public static int getCapacity(){
		return garageCapacity;
	}
	public static void setCapacity(int num){
		garageCapacity = num;
	}
	
}
