//Ryan Wu
//CS340

public class AlreadyWorking extends Thread {

	@Override
	public void run() {

		setName("Current Worker");
		Main.WORKING.arriveAtWork();
		Main.WORKING.currWorking();
		Commuting.msg(":is currently working and waiting for next worker.");
		Commuting.msg(":sees the next worker has arrived at " + Commuting.age() + " milliseconds.");
		Commuting.leaveWork();
	}
}
