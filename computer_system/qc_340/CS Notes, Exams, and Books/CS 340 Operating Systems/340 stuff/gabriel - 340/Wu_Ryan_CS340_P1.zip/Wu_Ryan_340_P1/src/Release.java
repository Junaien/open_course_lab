//Ryan Wu
//CS340

import java.util.Random;

public class Release extends Thread {

	private static Random generator = new Random();
	@Override
	public void run() {

		setName("Release Worker");
		int sleepTime = generator.nextInt(5)+1;
		sleepTime = sleepTime*1000;
		try {
			sleep(sleepTime);
			Main.WORKING.arriveAtWork();
			Commuting.msg(":is releasing the last worker of the day.");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
}