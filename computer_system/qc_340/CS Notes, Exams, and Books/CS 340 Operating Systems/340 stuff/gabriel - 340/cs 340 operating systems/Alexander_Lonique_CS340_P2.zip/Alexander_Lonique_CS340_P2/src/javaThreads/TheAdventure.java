package javaThreads;

import java.util.concurrent.Semaphore;

public class TheAdventure {
	private int count =0;
	private boolean isInBattle=false;			//let the adventurer know he has to wait
	private boolean isGameOver=false;			//tell the clerk and dragon to go home
	private boolean need_assistance =false;		//clerk wait for adventurer 
	private boolean isServing=false;			//serving a player
	private boolean isItheWinner=false;
	private boolean isDragonBusy = false;		//make the dragon wait
	private static Semaphore dragonMutex= new Semaphore(1);
	private static Semaphore clerkSemaphore= new Semaphore(2);
	public String helperArray[]= new String[]{"stone", "ring","necklaces", "magical ring","magical necklace" };

	
	//setters, when changing data should be synchronized 
	public void setIsInBattle(boolean tf){isInBattle=tf;}
	
	public void setIsSeving(boolean tf){isServing=tf;}
	
	public void setIsGameOver(boolean tf){isGameOver=tf;}
	
	public void setIsItheWinner(boolean tf){isItheWinner=tf;}
	
	public synchronized void setAvailable(boolean tf){isDragonBusy=tf;}
	
	public synchronized void setNeed_assistance(boolean tf){need_assistance=tf;}

	//getter
	public boolean isInBattle(){return isInBattle;}
	
	public boolean isGameOver(){return isGameOver;}
	
	public boolean isServing(){return isServing;}
	
	public boolean isItheWinner(){return isItheWinner;}
	
	public boolean getNeed_assistance(){return need_assistance;}

	public int numberOfThreads(){
		return ++count;
	}
	
	public synchronized boolean getAvailable(){return isDragonBusy;}
	
	public synchronized Semaphore getDragonSemaphore(){return dragonMutex;}
	
	public synchronized Semaphore getClerkSemaphore(){return clerkSemaphore;}
}
